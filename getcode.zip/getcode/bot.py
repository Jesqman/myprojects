"""
Main bot application
"""

import logging
import sys

from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters

from config import Config
from handlers import BotHandlers

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('bot.log')
    ]
)

logger = logging.getLogger(__name__)


class GetCodeGPTBot:
    """Main bot application"""
    
    def __init__(self):
        self.handlers = BotHandlers()
        self.app = None
        self._setup()
    
    def _setup(self):
        """Setup bot application"""
        self.app = Application.builder().token(Config.TELEGRAM_TOKEN).build()
        
        # Command handlers
        self.app.add_handler(CommandHandler("start", self.handlers.start))
        self.app.add_handler(CommandHandler("plan", self.handlers.show_plans))
        self.app.add_handler(CommandHandler("stats", self.handlers.show_stats))
        self.app.add_handler(CommandHandler("help", self.handlers.help_command))
        
        # Message handler
        self.app.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self.handlers.handle_message)
        )
        
        # Callback handler
        self.app.add_handler(CallbackQueryHandler(self.handlers.handle_callback))
        
        # Error handler
        self.app.add_error_handler(self._error_handler)
    
    async def _error_handler(self, update: Update, context):
        """Global error handler"""
        logger.error(f"Exception while handling update: {context.error}", exc_info=True)
        
        try:
            if update and update.effective_message:
                await update.effective_message.reply_text(
                    f"❌ Произошла ошибка. Попробуй позже или обратись в поддержку {Config.SUPPORT_USERNAME}"
                )
        except Exception:
            pass
    
    def run(self):
        """Start bot"""
        logger.info("🚀 GetCodeGPT Bot starting...")
        print("🚀 GetCodeGPT Production Bot")
        print(f"📊 Environment: {Config.ENVIRONMENT}")
        print(f"💾 Database: {Config.DATABASE_URL}")
        print(f"🔄 Redis: {Config.REDIS_URL}")
        print("✅ Bot is running!")
        
        # Start polling
        self.app.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )