"""
Configuration module for GetCodeGPT Bot
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Main configuration class"""
    
    # Bot Configuration
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
    CRYPTOBOT_API_KEY = os.getenv("CRYPTOBOT_API_KEY")
    
    # Database
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///getcodegpt.db")
    
    # Redis
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
    
    # Sentry
    SENTRY_DSN = os.getenv("SENTRY_DSN")
    ENVIRONMENT = os.getenv("ENVIRONMENT", "development")
    
    # Security Limits
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    MAX_FILES_PER_REQUEST = 50
    MAX_CODE_BLOCKS = 20
    REQUEST_TIMEOUT = 30
    RATE_LIMIT_REQUESTS = 10
    RATE_LIMIT_WINDOW = 60  # seconds
    
    # API URLs
    GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={GEMINI_API_KEY}"
    CRYPTOBOT_API_URL = "https://pay.crypt.bot/api"
    
    # Support
    SUPPORT_USERNAME = "@jesqman"
    SUPPORT_EMAIL = "jesqweb@gmail.com"
    
    # Cache TTL
    CACHE_TTL = 3600  # 1 hour
    
    @classmethod
    def validate(cls):
        """Validate required configuration"""
        required = ['TELEGRAM_TOKEN', 'GEMINI_API_KEY', 'CRYPTOBOT_API_KEY']
        missing = [key for key in required if not getattr(cls, key)]
        
        if missing:
            raise ValueError(f"Missing required environment variables: {', '.join(missing)}")
        
        return True