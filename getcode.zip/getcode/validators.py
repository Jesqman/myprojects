"""
Security validators and sanitizers
"""

import re
from config import Config


class SecurityValidator:
    """Security validation utilities"""
    
    @staticmethod
    def validate_url(url: str) -> bool:
        """Validate share URL"""
        pattern = r'^https://(claude\.ai|chatgpt\.com)/share/[\w-]+$'
        return bool(re.match(pattern, url))
    
    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """Sanitize filename to prevent path traversal"""
        # Remove dangerous characters
        filename = re.sub(r'[^\w\s.-]', '', filename)
        # Remove path separators
        filename = filename.replace('/', '_').replace('\\', '_')
        # Limit length
        filename = filename[:255]
        # Ensure not empty
        if not filename:
            filename = "file.txt"
        return filename
    
    @staticmethod
    def validate_code_size(code: str) -> bool:
        """Validate code size"""
        return len(code.encode('utf-8')) <= Config.MAX_FILE_SIZE
    
    @staticmethod
    def extract_url(text: str) -> str:
        """Extract URL from text"""
        url_match = re.search(
            r'https://(claude\.ai|chatgpt\.com)/share/[\w-]+',
            text
        )
        return url_match.group(0) if url_match else None