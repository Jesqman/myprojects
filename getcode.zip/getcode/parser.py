"""
Code parser service with anti-detection
"""

import re
import json
import logging
import asyncio
from typing import Dict, List, Any

import aiohttp
from playwright.async_api import async_playwright

from config import Config
from validators import SecurityValidator
from cache import cache_manager

logger = logging.getLogger(__name__)


class CodeParser:
    """Code parser with stealth mode"""
    
    def __init__(self):
        """Initialize parser with stealth settings"""
        self.browser_args = [
            '--disable-blink-features=AutomationControlled',
            '--disable-dev-shm-usage',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-gpu',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
            '--window-size=1920,1080'
        ]
        
        self.stealth_script = """
        Object.defineProperty(navigator, 'webdriver', {
            get: () => undefined
        });
        Object.defineProperty(navigator, 'plugins', {
            get: () => [1, 2, 3, 4, 5]
        });
        Object.defineProperty(navigator, 'languages', {
            get: () => ['en-US', 'en']
        });
        window.chrome = {
            runtime: {}
        };
        Object.defineProperty(navigator, 'permissions', {
            get: () => ({
                query: () => Promise.resolve({ state: 'granted' })
            })
        });
        """
    
    async def parse_url(self, url: str) -> Dict[str, Any]:
        """Parse code from URL with validation and caching"""
        
        # Validate URL
        if not SecurityValidator.validate_url(url):
            return {"error": "❌ Неверный формат ссылки"}
        
        # Check cache
        cache_key = f"parse:{url}"
        cached = await cache_manager.get(cache_key)
        if cached:
            logger.info(f"Cache hit for {url}")
            return cached
        
        try:
            # Parse based on platform
            if "claude.ai" in url:
                result = await self._parse_claude(url)
            elif "chatgpt.com" in url:
                result = await self._parse_chatgpt(url)
            else:
                result = {"error": "❌ Неподдерживаемая платформа"}
            
            # Cache successful result
            if "error" not in result:
                await cache_manager.set(cache_key, result)
            
            return result
            
        except asyncio.TimeoutError:
            logger.error(f"Timeout parsing {url}")
            return {"error": "⏱️ Превышено время ожидания"}
        except Exception as e:
            logger.error(f"Parse error for {url}: {e}", exc_info=True)
            return {"error": f"❌ Ошибка парсинга: {str(e)}"}
    
    async def _parse_claude(self, url: str) -> Dict[str, Any]:
        """Parse Claude share link"""
        async with async_playwright() as p:
            browser = None
            try:
                browser = await p.chromium.launch(
                    headless=True,
                    args=self.browser_args
                )
                
                context = await browser.new_context(
                    viewport={'width': 1920, 'height': 1080},
                    user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                    locale='en-US',
                    timezone_id='America/New_York',
                    permissions=['geolocation'],
                    geolocation={'latitude': 40.7128, 'longitude': -74.0060},
                    color_scheme='light'
                )
                
                page = await context.new_page()
                await page.add_init_script(self.stealth_script)
                
                await page.goto(url, wait_until='domcontentloaded', timeout=Config.REQUEST_TIMEOUT * 1000)
                await page.wait_for_timeout(2000)
                
                # Wait for code elements
                await page.wait_for_selector(
                    'pre code, [data-artifact-type], [class*="artifact"]',
                    timeout=10000
                )
                
                # Extract code blocks
                code_blocks = await page.evaluate(self._get_claude_extraction_script())
                
                await browser.close()
                
                if not code_blocks:
                    return {"error": "❌ Код не найден. Убедитесь, что ссылка содержит код."}
                
                # Limit blocks
                code_blocks = code_blocks[:Config.MAX_CODE_BLOCKS]
                
                # Validate size
                total_size = sum(len(block['code'].encode('utf-8')) for block in code_blocks)
                if total_size > Config.MAX_FILE_SIZE * len(code_blocks):
                    return {"error": "❌ Слишком большой объем кода"}
                
                # Extract files with AI
                files = await self._extract_files_with_ai(code_blocks)
                
                return {
                    "files": files,
                    "source": "Claude",
                    "blocks_count": len(code_blocks)
                }
                
            except Exception as e:
                if browser:
                    await browser.close()
                raise
    
    async def _parse_chatgpt(self, url: str) -> Dict[str, Any]:
        """Parse ChatGPT share link"""
        async with async_playwright() as p:
            browser = None
            try:
                browser = await p.chromium.launch(
                    headless=True,
                    args=self.browser_args
                )
                
                context = await browser.new_context(
                    viewport={'width': 1920, 'height': 1080},
                    user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                    locale='en-US'
                )
                
                page = await context.new_page()
                await page.add_init_script(self.stealth_script)
                
                await page.goto(url, wait_until='domcontentloaded', timeout=Config.REQUEST_TIMEOUT * 1000)
                await page.wait_for_timeout(2000)
                
                # Wait for code elements
                await page.wait_for_selector('pre code, code[class*="language-"]', timeout=10000)
                
                # Extract code blocks
                code_blocks = await page.evaluate(self._get_chatgpt_extraction_script())
                
                await browser.close()
                
                if not code_blocks:
                    return {"error": "❌ Код не найден в ссылке"}
                
                code_blocks = code_blocks[:Config.MAX_CODE_BLOCKS]
                
                files = await self._extract_files_with_ai(code_blocks)
                
                return {
                    "files": files,
                    "source": "ChatGPT",
                    "blocks_count": len(code_blocks)
                }
                
            except Exception as e:
                if browser:
                    await browser.close()
                raise
    
    async def _extract_files_with_ai(self, code_blocks: List[Dict]) -> List[Dict]:
        """Extract files using Gemini AI"""
        if not code_blocks:
            return []
        
        # Prepare code samples
        code_samples = []
        for i, block in enumerate(code_blocks[:10]):
            preview = block['code'][:500] + "..." if len(block['code']) > 500 else block['code']
            code_samples.append(f"Block {i+1} ({block['language']}):\n{preview}")
        
        prompt = f"""Analyze the code blocks and determine the project file structure.

Code blocks:
{chr(10).join(code_samples)}

Return ONLY valid JSON with this structure:
{{
    "files": [
        {{"name": "filename.ext", "block_index": 0, "language": "python"}},
        {{"name": "folder/file.ext", "block_index": 1, "language": "javascript"}}
    ],
    "project_name": "project_name"
}}

Rules:
1. Determine filenames from comments, imports, or content
2. Use block_index to reference which code block contains the file
3. Create proper folder structure if multiple files
4. Don't create README.md unless it's in the code
5. Return ONLY JSON without markdown formatting"""

        try:
            payload = {
                "contents": [{
                    "parts": [{
                        "text": prompt
                    }]
                }],
                "generationConfig": {
                    "temperature": 0.2,
                    "maxOutputTokens": 2048,
                    "topP": 0.8,
                    "topK": 10
                }
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    Config.GEMINI_API_URL,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=Config.REQUEST_TIMEOUT)
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if "candidates" in data and data["candidates"]:
                            text = data["candidates"][0]["content"]["parts"][0]["text"]
                            
                            # Clean markdown
                            text = re.sub(r'```json\s*', '', text)
                            text = re.sub(r'```\s*', '', text)
                            text = text.strip()
                            
                            try:
                                result = json.loads(text)
                                files = []
                                
                                for file_info in result.get("files", []):
                                    block_index = file_info.get("block_index", 0)
                                    if 0 <= block_index < len(code_blocks):
                                        filename = SecurityValidator.sanitize_filename(file_info["name"])
                                        files.append({
                                            "name": filename,
                                            "content": code_blocks[block_index]["code"],
                                            "language": file_info.get("language", code_blocks[block_index]["language"])
                                        })
                                
                                return files if files else self._fallback_extraction(code_blocks)
                                
                            except json.JSONDecodeError:
                                logger.error("Failed to parse AI response as JSON")
                                return self._fallback_extraction(code_blocks)
                    
                    logger.error(f"Gemini API error: {response.status}")
                    return self._fallback_extraction(code_blocks)
                    
        except Exception as e:
            logger.error(f"AI extraction error: {e}")
            return self._fallback_extraction(code_blocks)
    
    def _fallback_extraction(self, code_blocks: List[Dict]) -> List[Dict]:
        """Fallback file extraction without AI"""
        files = []
        for i, block in enumerate(code_blocks):
            ext = self._get_extension(block['language'])
            filename = f"code_{i+1}{ext}"
            
            # Try to find filename in code
            filename_match = re.search(r'(?:file|filename|File):\s*([^\s]+)', block['code'][:200])
            if filename_match:
                filename = SecurityValidator.sanitize_filename(filename_match.group(1))
            
            files.append({
                "name": filename,
                "content": block['code'],
                "language": block['language']
            })
        
        return files
    
    def _get_extension(self, language: str) -> str:
        """Get file extension by language"""
        extensions = {
            'python': '.py', 'javascript': '.js', 'typescript': '.ts',
            'java': '.java', 'cpp': '.cpp', 'c': '.c', 'go': '.go',
            'rust': '.rs', 'html': '.html', 'css': '.css', 'markdown': '.md',
            'json': '.json', 'yaml': '.yaml', 'yml': '.yml', 'sql': '.sql',
            'bash': '.sh', 'shell': '.sh', 'php': '.php', 'ruby': '.rb',
            'swift': '.swift', 'kotlin': '.kt', 'scala': '.scala',
            'r': '.r', 'matlab': '.m', 'julia': '.jl', 'dart': '.dart',
            'vue': '.vue', 'react': '.jsx', 'angular': '.ts'
        }
        return extensions.get(language.lower(), '.txt')
    
    def _get_claude_extraction_script(self) -> str:
        """JavaScript code for Claude extraction"""
        return """
        () => {
            const blocks = [];
            const processedTexts = new Set();
            
            const extractText = (element) => {
                const clone = element.cloneNode(true);
                clone.querySelectorAll('button, .copy-button, [class*="copy"]').forEach(el => el.remove());
                return clone.textContent.trim();
            };
            
            // Artifacts
            document.querySelectorAll('[data-artifact-type], [class*="artifact"]').forEach(el => {
                const code = extractText(el);
                if (code && code.length > 10 && !processedTexts.has(code)) {
                    processedTexts.add(code);
                    blocks.push({
                        code: code,
                        language: el.getAttribute('data-artifact-type') || 'python',
                        type: 'artifact'
                    });
                }
            });
            
            // Code blocks
            document.querySelectorAll('pre code, code[class*="language-"]').forEach(el => {
                const code = extractText(el);
                const className = el.className || el.parentElement?.className || '';
                const langMatch = className.match(/language-(\\w+)/);
                
                if (code && code.length > 10 && !processedTexts.has(code)) {
                    processedTexts.add(code);
                    blocks.push({
                        code: code,
                        language: langMatch ? langMatch[1] : 'text',
                        type: 'codeblock'
                    });
                }
            });
            
            return blocks;
        }
        """
    
    def _get_chatgpt_extraction_script(self) -> str:
        """JavaScript code for ChatGPT extraction"""
        return """
        () => {
            const blocks = [];
            const processedTexts = new Set();
            
            document.querySelectorAll('pre code, code[class*="language-"]').forEach(el => {
                const clone = el.cloneNode(true);
                clone.querySelectorAll('button').forEach(btn => btn.remove());
                const code = clone.textContent.trim();
                
                const className = el.className || '';
                const langMatch = className.match(/language-(\\w+)/);
                
                if (code && code.length > 10 && !processedTexts.has(code)) {
                    processedTexts.add(code);
                    blocks.push({
                        code: code,
                        language: langMatch ? langMatch[1] : 'text'
                    });
                }
            });
            
            return blocks;
        }
        """