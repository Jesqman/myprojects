"""
GetCodeGPT Bot - Main Entry Point
Production ready application
"""

import sys
import signal
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path

import sentry_sdk
from sentry_sdk.integrations.logging import LoggingIntegration

from config import Config
from models import init_db, engine
from cache import cache_manager
from bot import GetCodeGPTBot

logger = logging.getLogger(__name__)

# Global bot instance for signal handlers
bot_instance = None


def setup_logging():
    """Configure logging with file rotation"""
    # Create logs directory if not exists
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO if Config.ENVIRONMENT == "production" else logging.DEBUG)
    
    # Remove existing handlers
    root_logger.handlers.clear()
    
    # Console handler with colors
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_format = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(console_format)
    root_logger.addHandler(console_handler)
    
    # File handler with rotation
    file_handler = RotatingFileHandler(
        log_dir / "bot.log",
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.DEBUG)
    file_format = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(file_format)
    root_logger.addHandler(file_handler)
    
    # Error file handler
    error_handler = RotatingFileHandler(
        log_dir / "error.log",
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=5,
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(file_format)
    root_logger.addHandler(error_handler)
    
    logger.info("Logging configured successfully")


def init_sentry():
    """Initialize Sentry monitoring"""
    if Config.SENTRY_DSN:
        try:
            sentry_logging = LoggingIntegration(
                level=logging.INFO,
                event_level=logging.ERROR
            )
            
            sentry_sdk.init(
                dsn=Config.SENTRY_DSN,
                integrations=[sentry_logging],
                traces_sample_rate=0.1,
                environment=Config.ENVIRONMENT,
                release=f"getcodegpt-bot@1.0.0"
            )
            logger.info("✅ Sentry monitoring initialized")
        except Exception as e:
            logger.warning(f"⚠️ Sentry initialization failed: {e}")
    else:
        logger.info("ℹ️ Sentry monitoring disabled (no DSN provided)")


def check_environment():
    """Check environment and dependencies"""
    logger.info("Checking environment...")
    
    try:
        # Validate configuration
        Config.validate()
        logger.info("✅ Configuration validated")
        
        # Initialize database
        try:
            init_db()
            # Test database connection
            with engine.connect() as conn:
                conn.execute("SELECT 1")
            logger.info("✅ Database initialized and connected")
        except Exception as e:
            logger.error(f"❌ Database initialization failed: {e}")
            raise
        
        # Check Redis connection
        try:
            if cache_manager.client:
                cache_manager.client.ping()
                logger.info("✅ Redis connected")
            else:
                logger.warning("⚠️ Redis not available, caching disabled")
        except Exception as e:
            logger.warning(f"⚠️ Redis connection failed: {e} - Caching disabled")
        
        # Check required environment variables
        required_vars = ['TELEGRAM_TOKEN', 'GITHUB_TOKEN']
        missing_vars = [var for var in required_vars if not getattr(Config, var, None)]
        if missing_vars:
            logger.error(f"❌ Missing required environment variables: {', '.join(missing_vars)}")
            return False
        
        logger.info("✅ All environment checks passed")
        return True
        
    except Exception as e:
        logger.error(f"❌ Environment check failed: {e}", exc_info=True)
        return False


def signal_handler(signum, frame):
    """Handle shutdown signals gracefully"""
    signal_name = signal.Signals(signum).name
    logger.info(f"Received {signal_name} signal, shutting down gracefully...")
    
    global bot_instance
    if bot_instance:
        try:
            bot_instance.stop()
        except Exception as e:
            logger.error(f"Error stopping bot: {e}")
    
    # Close database connections
    try:
        engine.dispose()
        logger.info("Database connections closed")
    except Exception as e:
        logger.error(f"Error closing database: {e}")
    
    # Close Redis connection
    try:
        if cache_manager.client:
            cache_manager.client.close()
            logger.info("Redis connection closed")
    except Exception as e:
        logger.error(f"Error closing Redis: {e}")
    
    logger.info("Shutdown complete")
    sys.exit(0)


def setup_signal_handlers():
    """Setup signal handlers for graceful shutdown"""
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    logger.info("Signal handlers configured")


def print_startup_info():
    """Print startup information"""
    print("""
╔═══════════════════════════════════════╗
║   GetCodeGPT Bot - Production v1.0    ║
║   Professional AI Code Parser         ║
╚═══════════════════════════════════════╝
    """)
    
    print(f"Environment: {Config.ENVIRONMENT}")
    print(f"Database: {Config.DATABASE_URL.split('@')[-1] if '@' in Config.DATABASE_URL else 'SQLite'}")
    print(f"Redis: {'Enabled' if cache_manager.client else 'Disabled'}")
    print(f"Sentry: {'Enabled' if Config.SENTRY_DSN else 'Disabled'}")
    print(f"Log Level: {'INFO' if Config.ENVIRONMENT == 'production' else 'DEBUG'}")
    print("═" * 43)


def main():
    """Main application entry point"""
    global bot_instance
    
    try:
        # Setup logging first
        setup_logging()
        logger.info("=" * 50)
        logger.info("Starting GetCodeGPT Bot v1.0")
        logger.info("=" * 50)
        
        # Print startup info
        print_startup_info()
        
        # Initialize Sentry
        init_sentry()
        
        # Setup signal handlers
        setup_signal_handlers()
        
        # Check environment
        if not check_environment():
            logger.error("❌ Environment check failed. Please check configuration.")
            print("\n❌ Environment check failed. Please check logs for details.")
            sys.exit(1)
        
        # Start bot
        logger.info("Starting bot...")
        print("\n🚀 Starting bot...\n")
        
        bot_instance = GetCodeGPTBot()
        bot_instance.run()
        
    except KeyboardInterrupt:
        logger.info("Bot stopped by user (KeyboardInterrupt)")
        print("\n\n👋 Bot stopped gracefully")
        signal_handler(signal.SIGINT, None)
        
    except Exception as e:
        logger.critical(f"Critical error: {e}", exc_info=True)
        print(f"\n❌ Critical error: {e}")
        print("Check logs/error.log for details")
        
        # Try to send error to Sentry
        if Config.SENTRY_DSN:
            sentry_sdk.capture_exception(e)
        
        sys.exit(1)


if __name__ == "__main__":
    main()