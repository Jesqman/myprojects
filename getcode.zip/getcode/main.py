"""
GetCodeGPT Bot - Main Entry Point
Production ready application
"""

import sys
import logging

import sentry_sdk
from sentry_sdk.integrations.logging import LoggingIntegration

from config import Config
from models import init_db
from cache import cache_manager
from bot import GetCodeGPTBot

logger = logging.getLogger(__name__)


def init_sentry():
    """Initialize Sentry monitoring"""
    if Config.SENTRY_DSN:
        sentry_logging = LoggingIntegration(
            level=logging.INFO,
            event_level=logging.ERROR
        )
        
        sentry_sdk.init(
            dsn=Config.SENTRY_DSN,
            integrations=[sentry_logging],
            traces_sample_rate=0.1,
            environment=Config.ENVIRONMENT
        )
        logger.info("Sentry monitoring initialized")


def check_environment():
    """Check environment and dependencies"""
    try:
        # Validate configuration
        Config.validate()
        logger.info("✅ Configuration validated")
        
        # Initialize database
        init_db()
        logger.info("✅ Database initialized")
        
        # Check Redis connection
        if cache_manager.client:
            cache_manager.client.ping()
            logger.info("✅ Redis connected")
        else:
            logger.warning("⚠️ Redis not available, caching disabled")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Environment check failed: {e}", exc_info=True)
        return False


def main():
    """Main application entry point"""
    print("""
╔═══════════════════════════════════════╗
║   GetCodeGPT Bot - Production v1.0    ║
║   Professional AI Code Parser         ║
╚═══════════════════════════════════════╝
    """)
    
    try:
        # Initialize Sentry
        init_sentry()
        
        # Check environment
        if not check_environment():
            print("❌ Environment check failed. Please check logs.")
            sys.exit(1)
        
        # Start bot
        bot = GetCodeGPTBot()
        bot.run()
        
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
        print("\n👋 Bot stopped gracefully")
        sys.exit(0)
        
    except Exception as e:
        logger.critical(f"Critical error: {e}", exc_info=True)
        print(f"❌ Critical error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()