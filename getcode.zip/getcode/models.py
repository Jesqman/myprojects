"""
Database models for GetCodeGPT Bot
"""

from datetime import datetime, timedelta, timezone
from enum import Enum
from dataclasses import dataclass
from typing import List

from sqlalchemy import create_engine, Column, String, Integer, DateTime, Float, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

from config import Config

Base = declarative_base()


class PlanType(Enum):
    """User plan types"""
    FREE = "free"
    STANDARD = "standard"
    PREMIUM = "premium"


@dataclass
class Plan:
    """Plan configuration"""
    name: str
    limit: int
    zip_enabled: bool
    price: float
    currency: str = "USDT"
    features: List[str] = None


# Plan definitions
PLANS = {
    PlanType.FREE: Plan(
        name="Free",
        limit=5,
        zip_enabled=False,
        price=0,
        features=["5 запросов в день", "Базовый парсинг"]
    ),
    PlanType.STANDARD: Plan(
        name="Standard",
        limit=50,
        zip_enabled=False,
        price=5.0,
        features=["50 запросов в день", "Приоритетная поддержка"]
    ),
    PlanType.PREMIUM: Plan(
        name="Premium",
        limit=999999,
        zip_enabled=True,
        price=15.0,
        features=["Безлимит запросов", "ZIP архивы", "AI оптимизация", "API доступ"]
    )
}


def get_current_utc():
    """Get current UTC datetime"""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(Base):
    """User model"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False, index=True)
    username = Column(String(255))
    plan = Column(String(50), default=PlanType.FREE.value, nullable=False)
    usage_today = Column(Integer, default=0, nullable=False)
    total_usage = Column(Integer, default=0, nullable=False)
    last_reset = Column(DateTime, default=get_current_utc, nullable=False)
    registered_at = Column(DateTime, default=get_current_utc, nullable=False)
    plan_expires_at = Column(DateTime)
    is_active = Column(Boolean, default=True, nullable=False)
    
    # Relationship
    transactions = relationship("Transaction", back_populates="user", lazy="dynamic")
    
    def reset_daily_usage(self):
        """Reset daily usage if needed"""
        if self.last_reset is None:
            self.last_reset = get_current_utc()
            self.usage_today = 0
            return
        
        time_diff = get_current_utc() - self.last_reset
        if time_diff > timedelta(days=1):
            self.usage_today = 0
            self.last_reset = get_current_utc()
    
    def can_use(self) -> bool:
        """Check if user can make request"""
        self.reset_daily_usage()
        plan = PLANS[PlanType(self.plan)]
        return self.usage_today < plan.limit
    
    def increment_usage(self):
        """Increment usage counter"""
        self.reset_daily_usage()
        self.usage_today += 1
        self.total_usage += 1
    
    def __repr__(self):
        return f"<User(id={self.id}, telegram_id={self.telegram_id}, plan={self.plan})>"


class Transaction(Base):
    """Transaction model"""
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)
    invoice_id = Column(String(255), unique=True, nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(10), nullable=False)
    plan = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False)
    created_at = Column(DateTime, default=get_current_utc, nullable=False)
    paid_at = Column(DateTime)
    
    # Relationship
    user = relationship("User", back_populates="transactions")
    
    def __repr__(self):
        return f"<Transaction(id={self.id}, invoice_id={self.invoice_id}, status={self.status})>"


# Database setup
engine = create_engine(
    Config.DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    pool_recycle=3600,
    echo=False
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Initialize database"""
    Base.metadata.create_all(bind=engine)