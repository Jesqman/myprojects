"""
Database models for GetCodeGPT Bot
"""

from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass
from typing import List

from sqlalchemy import create_engine, Column, String, Integer, DateTime, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from config import Config

Base = declarative_base()


class PlanType(Enum):
    """User plan types"""
    FREE = "free"
    STANDARD = "standard"
    PREMIUM = "premium"


@dataclass
class Plan:
    """Plan configuration"""
    name: str
    limit: int
    zip_enabled: bool
    price: float
    currency: str = "USDT"
    features: List[str] = None


# Plan definitions
PLANS = {
    PlanType.FREE: Plan(
        name="Free",
        limit=5,
        zip_enabled=False,
        price=0,
        features=["5 запросов в день", "Базовый парсинг"]
    ),
    PlanType.STANDARD: Plan(
        name="Standard",
        limit=50,
        zip_enabled=False,
        price=5.0,
        features=["50 запросов в день", "Приоритетная поддержка"]
    ),
    PlanType.PREMIUM: Plan(
        name="Premium",
        limit=999999,
        zip_enabled=True,
        price=15.0,
        features=["Безлимит запросов", "ZIP архивы", "AI оптимизация", "API доступ"]
    )
}


class User(Base):
    """User model"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False, index=True)
    username = Column(String(255))
    plan = Column(String(50), default=PlanType.FREE.value)
    usage_today = Column(Integer, default=0)
    total_usage = Column(Integer, default=0)
    last_reset = Column(DateTime, default=datetime.utcnow)
    registered_at = Column(DateTime, default=datetime.utcnow)
    plan_expires_at = Column(DateTime)
    is_active = Column(Boolean, default=True)
    
    def reset_daily_usage(self):
        """Reset daily usage if needed"""
        if datetime.utcnow() - self.last_reset > timedelta(days=1):
            self.usage_today = 0
            self.last_reset = datetime.utcnow()
    
    def can_use(self) -> bool:
        """Check if user can make request"""
        self.reset_daily_usage()
        plan = PLANS[PlanType(self.plan)]
        return self.usage_today < plan.limit
    
    def increment_usage(self):
        """Increment usage counter"""
        self.usage_today += 1
        self.total_usage += 1


class Transaction(Base):
    """Transaction model"""
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=False, index=True)
    invoice_id = Column(String(255), unique=True)
    amount = Column(Float)
    currency = Column(String(10))
    plan = Column(String(50))
    status = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    paid_at = Column(DateTime)


# Database setup
engine = create_engine(Config.DATABASE_URL, pool_pre_ping=True, pool_size=20, max_overflow=40)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Initialize database"""
    Base.metadata.create_all(bind=engine)