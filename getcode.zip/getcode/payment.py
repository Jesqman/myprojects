"""
Payment service using CryptoBot API
"""

import json
import logging
from typing import Optional, Dict

import aiohttp

from config import Config
from models import Plan
from database import DatabaseManager

logger = logging.getLogger(__name__)


class PaymentService:
    """CryptoBot payment integration"""
    
    def __init__(self):
        self.headers = {
            "Crypto-Pay-API-Token": Config.CRYPTOBOT_API_KEY
        }
        self.api_url = Config.CRYPTOBOT_API_URL
    
    async def create_invoice(self, user_id: int, plan: Plan, description: str) -> Optional[Dict]:
        """Create payment invoice"""
        url = f"{self.api_url}/createInvoice"
        
        payload = {
            "amount": plan.price,
            "currency_type": "crypto",
            "asset": plan.currency,
            "description": description,
            "payload": json.dumps({
                "user_id": user_id,
                "plan": plan.name
            })
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    headers=self.headers,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=Config.REQUEST_TIMEOUT)
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if data.get("ok"):
                            result = data["result"]
                            
                            # Save transaction to database
                            DatabaseManager.create_transaction(
                                user_id=user_id,
                                invoice_id=result["invoice_id"],
                                amount=plan.price,
                                currency=plan.currency,
                                plan=plan.name
                            )
                            
                            logger.info(f"Invoice created for user {user_id}: {result['invoice_id']}")
                            return result
                    
                    error_text = await response.text()
                    logger.error(f"CryptoBot API error: {error_text}")
                    return None
                    
        except aiohttp.ClientError as e:
            logger.error(f"Payment creation network error: {e}")
            return None
        except Exception as e:
            logger.error(f"Payment creation error: {e}", exc_info=True)
            return None
    
    async def check_invoice(self, invoice_id: str) -> Optional[Dict]:
        """Check invoice payment status"""
        url = f"{self.api_url}/getInvoices"
        params = {"invoice_ids": invoice_id}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers=self.headers,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=Config.REQUEST_TIMEOUT)
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if data.get("ok") and data["result"]["items"]:
                            invoice = data["result"]["items"][0]
                            
                            # Update transaction status if paid
                            if invoice["status"] == "paid":
                                DatabaseManager.update_transaction_status(
                                    invoice_id=invoice_id,
                                    status="paid"
                                )
                                logger.info(f"Invoice {invoice_id} marked as paid")
                            
                            return invoice
                    
                    return None
                    
        except Exception as e:
            logger.error(f"Check invoice error: {e}", exc_info=True)
            return None