"""
Telegram bot handlers
"""

import logging
import asyncio
from io import BytesIO
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.error import TelegramError

from config import Config
from models import PLANS, PlanType
from database import DatabaseManager
from cache import rate_limiter
from validators import SecurityValidator
from parser import CodeParser
from payment import PaymentService
from utils import create_zip_archive, generate_readme

logger = logging.getLogger(__name__)


class BotHandlers:
    """Telegram bot command handlers"""
    
    def __init__(self):
        self.parser = CodeParser()
        self.payment = PaymentService()
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user = update.effective_user
        
        # Get or create user
        db_user = DatabaseManager.get_or_create_user(user.id, user.username)
        
        if db_user.total_usage == 0:
            logger.info(f"New user registered: {user.id} (@{user.username})")
        
        welcome_text = (
            "🚀 *GetCodeGPT - Профессиональный парсер кода*\n\n"
            "Я помогу извлечь код из AI-платформ:\n"
            "• Claude.ai - `claude.ai/share/...`\n"
            "• ChatGPT - `chatgpt.com/share/...`\n\n"
            "✨ *Возможности:*\n"
            "• Автоматическое определение структуры проекта\n"
            "• Сохранение с правильными именами файлов\n"
            "• ZIP архивы для Premium пользователей\n\n"
            "📋 *Команды:*\n"
            "/plan - Тарифные планы\n"
            "/stats - Твоя статистика\n"
            "/help - Помощь\n\n"
            "Просто отправь мне ссылку!"
        )
        
        await update.message.reply_text(
            welcome_text,
            parse_mode='Markdown',
            disable_web_page_preview=True
        )
    
    async def show_plans(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /plan command"""
        user_id = update.effective_user.id
        db_user = DatabaseManager.get_user(user_id)
        
        if not db_user:
            await update.message.reply_text("❌ Используй /start для начала")
            return
        
        current_plan = PlanType(db_user.plan)
        
        text = "💎 *Тарифные планы GetCodeGPT*\n\n"
        
        for plan_type, plan in PLANS.items():
            is_current = plan_type == current_plan
            emoji = "✅" if is_current else "📦"
            
            text += f"{emoji} *{plan.name}*"
            if plan.price > 0:
                text += f" - ${plan.price} {plan.currency}/месяц"
            else:
                text += " - Бесплатно"
            
            text += "\n"
            for feature in plan.features:
                text += f"   • {feature}\n"
            text += "\n"
        
        # Check subscription expiration
        if db_user.plan_expires_at and db_user.plan != PlanType.FREE.value:
            days_left = (db_user.plan_expires_at - datetime.utcnow()).days
            if days_left > 0:
                text += f"⏰ Твоя подписка активна еще {days_left} дней\n"
            else:
                text += "⚠️ Твоя подписка истекла\n"
        
        # Purchase buttons
        keyboard = []
        if current_plan != PlanType.STANDARD:
            keyboard.append([
                InlineKeyboardButton("📦 Купить Standard", callback_data="buy_standard")
            ])
        if current_plan != PlanType.PREMIUM:
            keyboard.append([
                InlineKeyboardButton("⭐ Купить Premium", callback_data="buy_premium")
            ])
        
        await update.message.reply_text(
            text,
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None
        )
    
    async def show_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stats command"""
        user_id = update.effective_user.id
        db_user = DatabaseManager.get_user(user_id)
        
        if not db_user:
            await update.message.reply_text("❌ Используй /start для начала")
            return
        
        db_user.reset_daily_usage()
        
        plan = PLANS[PlanType(db_user.plan)]
        remaining = max(0, plan.limit - db_user.usage_today)
        
        text = (
            f"📊 *Твоя статистика*\n\n"
            f"📦 Тариф: *{plan.name}*\n"
            f"📈 Использовано сегодня: {db_user.usage_today}/{plan.limit}\n"
            f"✅ Осталось: {remaining}\n"
            f"🔢 Всего запросов: {db_user.total_usage}\n"
            f"📅 Регистрация: {db_user.registered_at.strftime('%d.%m.%Y')}\n"
        )
        
        if db_user.plan_expires_at:
            days_left = (db_user.plan_expires_at - datetime.utcnow()).days
            text += f"⏰ Подписка до: {db_user.plan_expires_at.strftime('%d.%m.%Y')} ({days_left} дней)\n"
        
        await update.message.reply_text(text, parse_mode='Markdown')
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_text = (
            "❓ *Помощь по GetCodeGPT*\n\n"
            "*Как использовать:*\n"
            "1. Скопируй публичную ссылку на чат с кодом\n"
            "2. Отправь её мне\n"
            "3. Получи файлы с кодом\n\n"
            "*Поддерживаемые платформы:*\n"
            "• Claude.ai - Поделиться → Скопировать ссылку\n"
            "• ChatGPT - Share → Copy link\n\n"
            "*Частые вопросы:*\n"
            "Q: Код не найден?\n"
            "A: Убедись, что в чате есть код и ссылка публичная\n\n"
            "Q: Как получить ZIP?\n"
            "A: ZIP доступен только в Premium тарифе\n\n"
            f"*Поддержка:* {Config.SUPPORT_USERNAME}\n"
            f"*Email:* {Config.SUPPORT_EMAIL}"
        )
        
        await update.message.reply_text(
            help_text,
            parse_mode='Markdown',
            disable_web_page_preview=True
        )
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages (URLs)"""
        user_id = update.effective_user.id
        message_text = update.message.text.strip()
        
        # Rate limiting
        if not await rate_limiter.check_rate_limit(user_id):
            await update.message.reply_text(
                "⚠️ Слишком много запросов! Подожди минуту."
            )
            return
        
        # Get or create user
        db_user = DatabaseManager.get_or_create_user(
            user_id, 
            update.effective_user.username
        )
        
        # Check usage limits
        if not db_user.can_use():
            plan = PLANS[PlanType(db_user.plan)]
            await update.message.reply_text(
                f"⚠️ *Лимит исчерпан!*\n\n"
                f"Ты использовал все {plan.limit} запросов на сегодня.\n"
                f"Обнови тариф командой /plan",
                parse_mode='Markdown'
            )
            return
        
        # Extract URL
        url = SecurityValidator.extract_url(message_text)
        if not url:
            await update.message.reply_text(
                "❌ *Ссылка не найдена!*\n\n"
                "Отправь публичную share-ссылку из:\n"
                "• Claude: `claude.ai/share/...`\n"
                "• ChatGPT: `chatgpt.com/share/...`",
                parse_mode='Markdown'
            )
            return
        
        # Processing status
        status_msg = await update.message.reply_text("⏳ Анализирую ссылку...")
        
        try:
            # Parse URL
            result = await self.parser.parse_url(url)
            
            if "error" in result:
                await status_msg.edit_text(result['error'])
                return
            
            files = result.get('files', [])
            if not files:
                await status_msg.edit_text(
                    "❌ Код не найден. Проверь, что:\n"
                    "• В чате есть блоки кода\n"
                    "• Ссылка публичная (Share)\n"
                    "• Код не слишком большой"
                )
                return
            
            # Update usage
            DatabaseManager.increment_usage(user_id)
            
            # Save result in context
            context.user_data['last_result'] = result
            context.user_data['last_url'] = url
            
            logger.info(f"User {user_id} parsed {len(files)} files from {result['source']}")
            
            # Prepare response
            plan = PLANS[PlanType(db_user.plan)]
            
            keyboard = [[
                InlineKeyboardButton("📄 Получить файлы", callback_data=f"files:{url[:50]}")
            ]]
            
            if plan.zip_enabled:
                keyboard.append([
                    InlineKeyboardButton("📦 Скачать ZIP", callback_data=f"zip:{url[:50]}")
                ])
            else:
                keyboard.append([
                    InlineKeyboardButton("🔒 ZIP (Premium)", callback_data="need_premium")
                ])
            
            await status_msg.edit_text(
                f"✅ *Готово!*\n\n"
                f"📦 Найдено файлов: {len(files)}\n"
                f"🔍 Источник: {result['source']}\n"
                f"📊 Осталось сегодня: {plan.limit - db_user.usage_today - 1}\n\n"
                f"Выбери формат получения:",
                parse_mode='Markdown',
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            
        except Exception as e:
            logger.error(f"URL handling error: {e}", exc_info=True)
            await status_msg.edit_text(
                f"❌ Произошла ошибка при обработке.\n"
                f"Попробуй еще раз или обратись в поддержку {Config.SUPPORT_USERNAME}"
            )
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle callback queries"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        if data.startswith("buy_"):
            await self._handle_purchase(query, data)
        elif data.startswith("check_"):
            await self._handle_payment_check(query, data)
        elif data == "need_premium":
            await self._handle_need_premium(query)
        elif data.startswith(("files:", "zip:")):
            await self._handle_files(query, context, data)
    
    async def _handle_purchase(self, query, data: str):
        """Handle plan purchase"""
        plan_name = data.replace("buy_", "")
        
        if plan_name == "standard":
            plan_type = PlanType.STANDARD
        elif plan_name == "premium":
            plan_type = PlanType.PREMIUM
        else:
            await query.edit_message_text("❌ Неверный тариф")
            return
        
        plan = PLANS[plan_type]
        
        # Create invoice
        invoice = await self.payment.create_invoice(
            user_id=query.from_user.id,
            plan=plan,
            description=f"GetCodeGPT {plan.name} - 30 дней"
        )
        
        if invoice:
            keyboard = [[
                InlineKeyboardButton("💳 Оплатить", url=invoice['pay_url'])
            ], [
                InlineKeyboardButton("🔄 Проверить оплату", callback_data=f"check_{invoice['invoice_id']}")
            ]]
            
            await query.edit_message_text(
                f"💳 *Оплата {plan.name}*\n\n"
                f"💰 Сумма: ${plan.price} {plan.currency}\n"
                f"📅 Срок: 30 дней\n"
                f"🔐 Безопасная оплата через CryptoBot\n\n"
                f"После оплаты нажми 'Проверить оплату'",
                parse_mode='Markdown',
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await query.edit_message_text(
                f"❌ Ошибка создания счета. Попробуй позже или обратись в поддержку {Config.SUPPORT_USERNAME}"
            )
    
    async def _handle_payment_check(self, query, data: str):
        """Handle payment verification"""
        invoice_id = data.replace("check_", "")
        
        invoice = await self.payment.check_invoice(invoice_id)
        
        if invoice and invoice['status'] == 'paid':
            amount = float(invoice['amount'])
            
            # Find plan by price
            plan_type = None
            for pt, plan in PLANS.items():
                if plan.price == amount:
                    plan_type = pt
                    break
            
            if not plan_type:
                await query.edit_message_text("❌ Неизвестная сумма платежа")
                return
            
            # Update user plan
            DatabaseManager.update_user_plan(query.from_user.id, plan_type, duration_days=30)
            
            await query.edit_message_text(
                f"✅ *Оплата успешна!*\n\n"
                f"🎉 Тариф {PLANS[plan_type].name} активирован!\n"
                f"📅 Действует 30 дней\n\n"
                f"Теперь ты можешь использовать все возможности!",
                parse_mode='Markdown'
            )
            
            logger.info(f"User {query.from_user.id} upgraded to {plan_type.value}")
        else:
            await query.answer("⏳ Оплата еще не прошла. Проверь позже.", show_alert=True)
    
    async def _handle_need_premium(self, query):
        """Handle premium required"""
        await query.answer("⭐ ZIP архивы доступны только в Premium!", show_alert=True)
        await query.message.reply_text(
            "⭐ *Обнови до Premium!*\n\n"
            "• Безлимитные запросы\n"
            "• ZIP архивы проектов\n"
            "• AI оптимизация кода\n\n"
            "Используй /plan для покупки",
            parse_mode='Markdown'
        )
    
    async def _handle_files(self, query, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle file delivery"""
        action, _ = data.split(":", 1)
        
        result = context.user_data.get('last_result')
        if not result:
            await query.edit_message_text("❌ Данные устарели. Отправь ссылку заново.")
            return
        
        files = result['files']
        
        if action == "files":
            await self._send_individual_files(query, files)
        elif action == "zip":
            await self._send_zip_archive(query, files, result)
    
    async def _send_individual_files(self, query, files: list):
        """Send files individually"""
        await query.edit_message_text("📤 Отправляю файлы...")
        
        sent_count = 0
        errors = 0
        
        for i, file in enumerate(files[:15]):  # Telegram limit
            try:
                content = file['content'].encode('utf-8')
                if len(content) > 50 * 1024 * 1024:
                    await query.message.reply_text(f"⚠️ Файл {file['name']} слишком большой")
                    continue
                
                await query.message.reply_document(
                    document=BytesIO(content),
                    filename=file['name'],
                    caption=f"📄 `{file['name']}` ({file['language']})",
                    parse_mode='Markdown'
                )
                sent_count += 1
                
                if i < len(files) - 1:
                    await asyncio.sleep(0.5)
                    
            except TelegramError as e:
                logger.error(f"Telegram error sending file: {e}")
                errors += 1
            except Exception as e:
                logger.error(f"Error sending file: {e}")
                errors += 1
        
        status_text = f"✅ Отправлено: {sent_count}/{len(files)}"
        if errors > 0:
            status_text += f"\n⚠️ Ошибок: {errors}"
        
        await query.message.reply_text(status_text)
    
    async def _send_zip_archive(self, query, files: list, result: dict):
        """Send ZIP archive"""
        await query.edit_message_text("📦 Создаю ZIP архив...")
        
        try:
            # Create ZIP
            zip_buffer = create_zip_archive(files, result)
            
            # Generate filename
            project_name = result.get('project_name', 'project')
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            zip_filename = f"{project_name}_{timestamp}.zip"
            
            # Send ZIP
            await query.message.reply_document(
                document=zip_buffer,
                filename=zip_filename,
                caption=(
                    f"📦 *Проект готов!*\n\n"
                    f"📁 Файлов: {len(files)}\n"
                    f"🔍 Источник: {result['source']}\n"
                    f"📅 Дата: {datetime.utcnow().strftime('%d.%m.%Y %H:%M')}"
                ),
                parse_mode='Markdown'
            )
            
            await query.message.reply_text("✅ ZIP архив успешно создан!")
            
        except Exception as e:
            logger.error(f"ZIP creation error: {e}", exc_info=True)
            await query.message.reply_text(f"❌ Ошибка создания архива: {str(e)}")