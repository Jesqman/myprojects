# GetCodeGPT Bot - Production Ready

Professional Telegram bot for extracting code from AI platforms (Claude.ai, ChatGPT) with monetization.

## 🚀 Features

- **Multi-Platform Support**: Claude.ai and ChatGPT share links
- **Smart Code Extraction**: AI-powered file structure detection using Gemini
- **Anti-Detection**: Stealth browser automation with Playwright
- **Monetization**: Crypto payments via CryptoBot
- **Scalable Architecture**: Modular design with caching and rate limiting
- **Production Ready**: Error handling, logging, monitoring with Sentry

## 📁 Project Structure

```
getcodegpt/
├── main.py                 # Application entry point
├── bot.py                  # Main bot application
├── config.py               # Configuration management
├── models.py               # Database models
├── database.py             # Database operations
├── cache.py                # Redis cache & rate limiting
├── validators.py           # Security validators
├── payment.py              # Payment service
├── parser.py               # Code parser service
├── handlers.py             # Telegram bot handlers
├── utils.py                # Utility functions
├── requirements.txt        # Python dependencies
├── Dockerfile              # Docker configuration
├── docker-compose.yml      # Docker Compose setup
├── .env.example            # Environment variables template
└── README.md               # This file
```

## 🛠️ Installation

### Prerequisites

- Python 3.11+
- PostgreSQL (or SQLite for development)
- Redis
- Docker & Docker Compose (optional)

### Local Setup

1. **Clone repository**
```bash
git clone <repository-url>
cd getcodegpt
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
playwright install chromium
```

4. **Configure environment**
```bash
cp .env.example .env
# Edit .env with your credentials
```

5. **Initialize database**
```bash
python -c "from models import init_db; init_db()"
```

6. **Run bot**
```bash
python main.py
```

### Docker Setup

1. **Configure environment**
```bash
cp .env.example .env
# Edit .env with your credentials
```

2. **Start services**
```bash
docker-compose up -d
```

3. **View logs**
```bash
docker-compose logs -f bot
```

4. **Stop services**
```bash
docker-compose down
```

## 🔧 Configuration

### Required Environment Variables

- `TELEGRAM_TOKEN` - Telegram bot token from @BotFather
- `GEMINI_API_KEY` - Google Gemini API key
- `CRYPTOBOT_API_KEY` - CryptoBot API key for payments

### Optional Environment Variables

- `DATABASE_URL` - Database connection string (default: SQLite)
- `REDIS_URL` - Redis connection string (default: localhost)
- `SENTRY_DSN` - Sentry DSN for error monitoring
- `ENVIRONMENT` - Environment name (development/production)

### Getting API Keys

1. **Telegram Bot Token**:
   - Message @BotFather on Telegram
   - Create new bot with `/newbot`
   - Copy the token

2. **Gemini API Key**:
   - Visit https://makersuite.google.com/app/apikey
   - Create new API key

3. **CryptoBot API Key**:
   - Message @CryptoBot on Telegram
   - Go to "Crypto Pay" → "Create App"
   - Copy the API token

## 📊 Database Schema

### Users Table
- `id` - Primary key
- `telegram_id` - Telegram user ID (unique)
- `username` - Telegram username
- `plan` - Current plan (free/standard/premium)
- `usage_today` - Daily usage counter
- `total_usage` - Total requests
- `last_reset` - Last daily reset timestamp
- `registered_at` - Registration date
- `plan_expires_at` - Plan expiration date
- `is_active` - Account status

### Transactions Table
- `id` - Primary key
- `user_id` - User ID
- `invoice_id` - CryptoBot invoice ID
- `amount` - Payment amount
- `currency` - Payment currency
- `plan` - Purchased plan
- `status` - Transaction status
- `created_at` - Creation timestamp
- `paid_at` - Payment timestamp

## 🎯 Usage

### User Commands

- `/start` - Start bot and show welcome message
- `/plan` - View pricing plans and purchase
- `/stats` - View personal statistics
- `/help` - Show help information

### Parsing Code

1. Share conversation from Claude.ai or ChatGPT
2. Copy public share link
3. Send link to bot
4. Choose delivery format (individual files or ZIP)

## 💳 Pricing Plans

### Free
- 5 requests per day
- Basic parsing
- Individual file delivery

### Standard ($5/month)
- 50 requests per day
- Priority support
- Individual file delivery

### Premium ($15/month)
- Unlimited requests
- ZIP archives
- AI optimization
- API access

## 🔒 Security Features

- URL validation and sanitization
- Filename sanitization (prevents path traversal)
- File size limits
- Rate limiting (10 requests/minute)
- Request timeout protection
- SQL injection prevention (SQLAlchemy ORM)
- XSS prevention

## 🚦 Rate Limiting

- 10 requests per minute per user
- Daily limits based on plan
- Automatic reset at midnight UTC
- Redis-based tracking

## 📈 Monitoring

### Sentry Integration
- Automatic error tracking
- Performance monitoring
- User context in errors
- Environment separation

### Logging
- Structured logging to file and console
- Log rotation
- Error level filtering
- User action tracking

## 🧪 Testing

```bash
# Run tests (when implemented)
pytest tests/

# Check code quality
flake8 .
black --check .

# Type checking
mypy .
```

## 🚀 Deployment

### Production Checklist

- [ ] Set `ENVIRONMENT=production`
- [ ] Configure PostgreSQL
- [ ] Configure Redis with persistence
- [ ] Set up Sentry monitoring
- [ ] Enable HTTPS for webhooks (optional)
- [ ] Set up backup strategy
- [ ] Configure log rotation
- [ ] Set resource limits in docker-compose
- [ ] Enable firewall rules
- [ ] Set up monitoring/alerting

### Recommended Server Specs

**Minimum**:
- 2 CPU cores
- 2GB RAM
- 10GB storage
- Ubuntu 22.04 LTS

**Recommended**:
- 4 CPU cores
- 4GB RAM
- 20GB storage
- Ubuntu 22.04 LTS

## 🔄 Updates & Maintenance

### Database Migrations

```bash
# Create migration
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head
```

### Updating Dependencies

```bash
pip install --upgrade -r requirements.txt
playwright install chromium
```

### Backup Database

```bash
# PostgreSQL
pg_dump -U postgres getcodegpt > backup.sql

# Restore
psql -U postgres getcodegpt < backup.sql
```

## 🐛 Troubleshooting

### Bot Not Starting

1. Check environment variables
2. Verify API tokens
3. Check database connection
4. Check Redis connection
5. Review logs in `bot.log`

### Parsing Errors

1. Verify share link is public
2. Check Playwright installation
3. Increase timeout in config
4. Check network connectivity

### Payment Issues

1. Verify CryptoBot API key
2. Check webhook configuration
3. Review transaction logs
4. Contact CryptoBot support

## 📞 Support

- **Telegram**: @jesqman
- **Email**: jesqweb@gmail.com
- **Issues**: GitHub Issues

## 📄 License

MIT License - see LICENSE file

## 🤝 Contributing

Contributions welcome! Please:

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 🙏 Acknowledgments

- Telegram Bot API
- Google Gemini API
- CryptoBot Payment API
- Playwright Browser Automation
- Open source community

## 📝 Changelog

### v1.0.0 (2024-01-XX)
- Initial production release
- Multi-platform support
- Payment integration
- AI-powered extraction
- Complete architecture rewrite

---

**Made with ❤️ for developers by developers**