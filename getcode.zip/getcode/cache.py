"""
Cache manager using Redis
"""

import json
import logging
from typing import Optional, Dict, Any

import redis

from config import Config

logger = logging.getLogger(__name__)


class CacheManager:
    """Redis cache manager"""
    
    def __init__(self):
        try:
            self.client = redis.from_url(Config.REDIS_URL, decode_responses=True)
            self.client.ping()
            logger.info("Redis connection established")
        except Exception as e:
            logger.error(f"Redis connection failed: {e}")
            self.client = None
    
    async def get(self, key: str) -> Optional[Dict[str, Any]]:
        """Get value from cache"""
        if not self.client:
            return None
        
        try:
            data = self.client.get(f"cache:{key}")
            return json.loads(data) if data else None
        except Exception as e:
            logger.error(f"Cache get error: {e}")
            return None
    
    async def set(self, key: str, value: Dict[str, Any], ttl: int = None):
        """Set value in cache"""
        if not self.client:
            return
        
        ttl = ttl or Config.CACHE_TTL
        
        try:
            self.client.setex(
                f"cache:{key}",
                ttl,
                json.dumps(value)
            )
        except Exception as e:
            logger.error(f"Cache set error: {e}")
    
    async def delete(self, key: str):
        """Delete value from cache"""
        if not self.client:
            return
        
        try:
            self.client.delete(f"cache:{key}")
        except Exception as e:
            logger.error(f"Cache delete error: {e}")
    
    def incr(self, key: str) -> int:
        """Increment counter"""
        if not self.client:
            return 0
        
        try:
            return self.client.incr(key)
        except Exception as e:
            logger.error(f"Cache incr error: {e}")
            return 0
    
    def expire(self, key: str, seconds: int):
        """Set expiration time"""
        if not self.client:
            return
        
        try:
            self.client.expire(key, seconds)
        except Exception as e:
            logger.error(f"Cache expire error: {e}")


class RateLimiter:
    """Rate limiting using Redis"""
    
    def __init__(self, cache: CacheManager):
        self.cache = cache
    
    async def check_rate_limit(self, user_id: int) -> bool:
        """Check if user exceeded rate limit"""
        key = f"rate_limit:{user_id}"
        current = self.cache.incr(key)
        
        if current == 1:
            self.cache.expire(key, Config.RATE_LIMIT_WINDOW)
        
        return current <= Config.RATE_LIMIT_REQUESTS
    
    async def add_request(self, user_id: int):
        """Add request to counter"""
        key = f"rate_limit:{user_id}"
        self.cache.incr(key)
        self.cache.expire(key, Config.RATE_LIMIT_WINDOW)


# Global cache instance
cache_manager = CacheManager()
rate_limiter = RateLimiter(cache_manager)