"""
Database manager for GetCodeGPT Bot
"""

import logging
from typing import Optional
from datetime import datetime, timedelta
from contextlib import contextmanager

from models import SessionLocal, User, Transaction, PlanType

logger = logging.getLogger(__name__)


class DatabaseManager:
    """Database operations manager"""
    
    @staticmethod
    @contextmanager
    def get_session():
        """Get database session with automatic cleanup"""
        session = SessionLocal()
        try:
            yield session
        except Exception as e:
            session.rollback()
            logger.error(f"Database session error: {e}", exc_info=True)
            raise e
        finally:
            session.close()
    
    @staticmethod
    def get_user(telegram_id: int) -> Optional[User]:
        """Get user by telegram ID"""
        try:
            telegram_id = int(telegram_id)
            with DatabaseManager.get_session() as db:
                user = db.query(User).filter(User.telegram_id == telegram_id).first()
                if user:
                    # Загружаем все необходимые атрибуты до закрытия сессии
                    db.refresh(user)
                    # Делаем объект независимым от сессии
                    db.expunge(user)
                return user
        except Exception as e:
            logger.error(f"Error getting user {telegram_id}: {e}", exc_info=True)
            return None
    
    @staticmethod
    def create_user(telegram_id: int, username: str = None) -> Optional[User]:
        """Create new user"""
        try:
            telegram_id = int(telegram_id)
            with DatabaseManager.get_session() as db:
                user = User(
                    telegram_id=telegram_id,
                    username=username
                )
                db.add(user)
                db.commit()
                db.refresh(user)
                # Делаем объект независимым от сессии
                db.expunge(user)
                logger.info(f"Created new user: {telegram_id} (@{username})")
                return user
        except Exception as e:
            logger.error(f"Error creating user {telegram_id}: {e}", exc_info=True)
            return None
    
    @staticmethod
    def get_or_create_user(telegram_id: int, username: str = None) -> Optional[User]:
        """Get existing user or create new one"""
        try:
            telegram_id = int(telegram_id)
            user = DatabaseManager.get_user(telegram_id)
            if not user:
                user = DatabaseManager.create_user(telegram_id, username)
            elif username and user.username != username:
                # Update username if changed
                with DatabaseManager.get_session() as db:
                    db_user = db.query(User).filter(User.telegram_id == telegram_id).first()
                    if db_user:
                        db_user.username = username
                        db.commit()
                        db.refresh(db_user)
                        db.expunge(db_user)
                        user = db_user
            return user
        except Exception as e:
            logger.error(f"Error in get_or_create_user {telegram_id}: {e}", exc_info=True)
            return None
    
    @staticmethod
    def update_user_plan(telegram_id: int, plan: PlanType, duration_days: int = 30) -> bool:
        """Update user plan"""
        try:
            telegram_id = int(telegram_id)
            with DatabaseManager.get_session() as db:
                user = db.query(User).filter(User.telegram_id == telegram_id).first()
                if user:
                    user.plan = plan.value
                    user.plan_expires_at = datetime.utcnow() + timedelta(days=duration_days)
                    user.usage_today = 0
                    db.commit()
                    logger.info(f"Updated user {telegram_id} plan to {plan.value}")
                    return True
                else:
                    logger.warning(f"User {telegram_id} not found for plan update")
                    return False
        except Exception as e:
            logger.error(f"Error updating user plan {telegram_id}: {e}", exc_info=True)
            return False
    
    @staticmethod
    def increment_usage(telegram_id: int) -> bool:
        """Increment user usage counter"""
        try:
            telegram_id = int(telegram_id)
            with DatabaseManager.get_session() as db:
                user = db.query(User).filter(User.telegram_id == telegram_id).first()
                if user:
                    user.increment_usage()
                    db.commit()
                    return True
                else:
                    logger.warning(f"User {telegram_id} not found for usage increment")
                    return False
        except Exception as e:
            logger.error(f"Error incrementing usage {telegram_id}: {e}", exc_info=True)
            return False
    
    @staticmethod
    def create_transaction(user_id: int, invoice_id: str, amount: float, 
                          currency: str, plan: str) -> Optional[Transaction]:
        """Create new transaction"""
        try:
            user_id = int(user_id)
            with DatabaseManager.get_session() as db:
                transaction = Transaction(
                    user_id=user_id,
                    invoice_id=invoice_id,
                    amount=amount,
                    currency=currency,
                    plan=plan,
                    status="pending"
                )
                db.add(transaction)
                db.commit()
                db.refresh(transaction)
                db.expunge(transaction)
                logger.info(f"Created transaction {invoice_id} for user {user_id}")
                return transaction
        except Exception as e:
            logger.error(f"Error creating transaction: {e}", exc_info=True)
            return None
    
    @staticmethod
    def update_transaction_status(invoice_id: str, status: str) -> bool:
        """Update transaction status"""
        try:
            with DatabaseManager.get_session() as db:
                transaction = db.query(Transaction).filter(
                    Transaction.invoice_id == invoice_id
                ).first()
                
                if transaction:
                    transaction.status = status
                    if status == "paid":
                        transaction.paid_at = datetime.utcnow()
                    db.commit()
                    logger.info(f"Updated transaction {invoice_id} status to {status}")
                    return True
                else:
                    logger.warning(f"Transaction {invoice_id} not found")
                    return False
        except Exception as e:
            logger.error(f"Error updating transaction status: {e}", exc_info=True)
            return False
    
    @staticmethod
    def get_transaction(invoice_id: str) -> Optional[Transaction]:
        """Get transaction by invoice ID"""
        try:
            with DatabaseManager.get_session() as db:
                transaction = db.query(Transaction).filter(
                    Transaction.invoice_id == invoice_id
                ).first()
                if transaction:
                    db.refresh(transaction)
                    db.expunge(transaction)
                return transaction
        except Exception as e:
            logger.error(f"Error getting transaction {invoice_id}: {e}", exc_info=True)
            return None
    
    @staticmethod
    def get_user_transactions(telegram_id: int, limit: int = 10) -> list:
        """Get user transactions"""
        try:
            telegram_id = int(telegram_id)
            with DatabaseManager.get_session() as db:
                user = db.query(User).filter(User.telegram_id == telegram_id).first()
                if not user:
                    return []
                
                transactions = db.query(Transaction).filter(
                    Transaction.user_id == user.id
                ).order_by(Transaction.created_at.desc()).limit(limit).all()
                
                # Делаем все объекты независимыми от сессии
                for transaction in transactions:
                    db.expunge(transaction)
                
                return transactions
        except Exception as e:
            logger.error(f"Error getting user transactions {telegram_id}: {e}", exc_info=True)
            return []
    
    @staticmethod
    def cleanup_expired_plans():
        """Reset expired plans to FREE"""
        try:
            with DatabaseManager.get_session() as db:
                expired_users = db.query(User).filter(
                    User.plan_expires_at < datetime.utcnow(),
                    User.plan != PlanType.FREE.value
                ).all()
                
                count = 0
                for user in expired_users:
                    user.plan = PlanType.FREE.value
                    user.plan_expires_at = None
                    logger.info(f"Reset expired plan for user {user.telegram_id}")
                    count += 1
                
                db.commit()
                return count
        except Exception as e:
            logger.error(f"Error cleaning up expired plans: {e}", exc_info=True)
            return 0