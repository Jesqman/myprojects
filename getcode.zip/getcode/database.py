"""
Database manager for GetCodeGPT Bot
"""

from typing import Optional
from datetime import datetime, timedelta
from contextlib import contextmanager

from models import SessionLocal, User, Transaction, PlanType


class DatabaseManager:
    """Database operations manager"""
    
    @staticmethod
    @contextmanager
    def get_session():
        """Get database session with automatic cleanup"""
        session = SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
    
    @staticmethod
    def get_user(telegram_id: int) -> Optional[User]:
        """Get user by telegram ID"""
        with DatabaseManager.get_session() as db:
            return db.query(User).filter(User.telegram_id == telegram_id).first()
    
    @staticmethod
    def create_user(telegram_id: int, username: str = None) -> User:
        """Create new user"""
        with DatabaseManager.get_session() as db:
            user = User(
                telegram_id=telegram_id,
                username=username
            )
            db.add(user)
            db.commit()
            db.refresh(user)
            return user
    
    @staticmethod
    def get_or_create_user(telegram_id: int, username: str = None) -> User:
        """Get existing user or create new one"""
        user = DatabaseManager.get_user(telegram_id)
        if not user:
            user = DatabaseManager.create_user(telegram_id, username)
        return user
    
    @staticmethod
    def update_user_plan(telegram_id: int, plan: PlanType, duration_days: int = 30):
        """Update user plan"""
        with DatabaseManager.get_session() as db:
            user = db.query(User).filter(User.telegram_id == telegram_id).first()
            if user:
                user.plan = plan.value
                user.plan_expires_at = datetime.utcnow() + timedelta(days=duration_days)
                user.usage_today = 0
                db.commit()
    
    @staticmethod
    def increment_usage(telegram_id: int):
        """Increment user usage counter"""
        with DatabaseManager.get_session() as db:
            user = db.query(User).filter(User.telegram_id == telegram_id).first()
            if user:
                user.increment_usage()
                db.commit()
    
    @staticmethod
    def create_transaction(user_id: int, invoice_id: str, amount: float, 
                          currency: str, plan: str) -> Transaction:
        """Create new transaction"""
        with DatabaseManager.get_session() as db:
            transaction = Transaction(
                user_id=user_id,
                invoice_id=invoice_id,
                amount=amount,
                currency=currency,
                plan=plan,
                status="pending"
            )
            db.add(transaction)
            db.commit()
            db.refresh(transaction)
            return transaction
    
    @staticmethod
    def update_transaction_status(invoice_id: str, status: str):
        """Update transaction status"""
        with DatabaseManager.get_session() as db:
            transaction = db.query(Transaction).filter(
                Transaction.invoice_id == invoice_id
            ).first()
            
            if transaction:
                transaction.status = status
                if status == "paid":
                    transaction.paid_at = datetime.utcnow()
                db.commit()