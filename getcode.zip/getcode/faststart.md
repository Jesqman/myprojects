# GetCodeGPT Bot - Quick Start Guide

## 5-Minute Setup

### Step 1: Get API Keys (5 min)

1. **Telegram Bot Token**
   - Open Telegram, find @BotFather
   - Send `/newbot`
   - Follow instructions
   - Copy token: `1234567890:ABCdef...`

2. **Gemini API Key**
   - Visit: https://makersuite.google.com/app/apikey
   - Click "Create API Key"
   - Copy key: `AIzaSy...`

3. **CryptoBot API Key**
   - Open Telegram, find @CryptoBot
   - Click "Crypto Pay"
   - Create App
   - Copy token: `12345:AA...`

### Step 2: Deploy with Docker (2 min)

```bash
# Clone repository
git clone <your-repo-url> getcodegpt
cd getcodegpt

# Configure environment
cp .env.example .env
nano .env  # Paste your API keys

# Start everything
docker-compose up -d

# Check logs
docker-compose logs -f bot
```

### Step 3: Test Bot (1 min)

1. Open Telegram
2. Find your bot (@your_bot_name)
3. Send `/start`
4. Send a Claude or ChatGPT share link
5. Get your code!

## Configuration File (.env)

```env
# Paste your tokens here
TELEGRAM_TOKEN=1234567890:ABCdef_your_token_here
GEMINI_API_KEY=AIzaSy_your_key_here
CRYPTOBOT_API_KEY=12345:AA_your_token_here

# These are fine as defaults
DATABASE_URL=postgresql://postgres:postgres@db:5432/getcodegpt
REDIS_URL=redis://redis:6379
ENVIRONMENT=production
```

## Without Docker (Development)

```bash
# Install Python 3.11+
python3 --version

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
playwright install chromium

# Configure
cp .env.example .env
nano .env  # Add your keys

# Run
python main.py
```

## Project Structure Overview

```
getcodegpt/
├── main.py          # Start here - runs the bot
├── bot.py           # Bot application setup
├── handlers.py      # Telegram commands (/start, /help, etc)
├── parser.py        # Code extraction logic
├── payment.py       # Payment processing
├── models.py        # Database tables
├── database.py      # Database operations
├── cache.py         # Redis caching
├── config.py        # Settings
├── validators.py    # Security checks
└── utils.py         # Helper functions
```

## Common Commands

```bash
# View logs
docker-compose logs -f bot

# Restart bot
docker-compose restart bot

# Stop everything
docker-compose down

# Start again
docker-compose up -d

# Rebuild after code changes
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

## Testing Share Links

### Get Claude Share Link
1. Go to claude.ai
2. Have a conversation with code
3. Click Share button
4. Copy public link: `https://claude.ai/share/xxx`

### Get ChatGPT Share Link
1. Go to chatgpt.com
2. Have a conversation with code
3. Click Share button
4. Copy link: `https://chatgpt.com/share/xxx`

### Send to Bot
Just paste the link in Telegram - bot will handle the rest!

## Pricing Setup

Default plans are configured in `models.py`:

- **Free**: 5 requests/day
- **Standard**: $5/month, 50 requests/day
- **Premium**: $15/month, unlimited

Change prices in `models.py` if needed.

## Troubleshooting

### Bot doesn't start
```bash
# Check environment variables
cat .env

# Check Docker status
docker-compose ps

# View errors
docker-compose logs bot
```

### Can't parse links
```bash
# Playwright might need reinstall
docker-compose exec bot playwright install chromium

# Or rebuild container
docker-compose build --no-cache bot
```

### Database errors
```bash
# Reset database
docker-compose down -v
docker-compose up -d
```

### Payment not working
- Double-check CRYPTOBOT_API_KEY
- Test invoice creation manually
- Check CryptoBot dashboard

## Production Checklist

Before going live:

- [ ] Change default passwords in docker-compose.yml
- [ ] Set ENVIRONMENT=production in .env
- [ ] Configure Sentry DSN for error tracking
- [ ] Set up database backups (see DEPLOYMENT.md)
- [ ] Configure firewall rules
- [ ] Test all bot commands
- [ ] Test payment flow
- [ ] Monitor logs for 24 hours

## Next Steps

1. **Read Full Documentation**: Check README.md for detailed info
2. **Deploy to Production**: Follow DEPLOYMENT.md guide
3. **Customize Messages**: Edit text in handlers.py
4. **Add Features**: Modular architecture makes it easy
5. **Monitor**: Set up Sentry and logging

## Getting Help

- **Documentation**: README.md, DEPLOYMENT.md
- **Support Email**: jesqweb@gmail.com
- **Telegram**: @jesqman
- **Logs**: Always check `docker-compose logs -f`

## Security Notes

- Never commit .env file to git
- Keep API keys secret
- Use strong database passwords
- Enable firewall on production server
- Regular backups recommended

## Performance Tips

- Redis speeds up repeated requests
- Gemini AI optimizes file detection
- Playwright uses headless browser (fast)
- PostgreSQL handles concurrent users
- Docker makes scaling easy

## One-Line Deploy

For experienced users:

```bash
git clone <repo> bot && cd bot && cp .env.example .env && nano .env && docker-compose up -d && docker-compose logs -f bot
```

---

**You're ready to go! Send your first link and watch the magic happen.**