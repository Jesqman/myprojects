# Production Deployment Guide

## Quick Start

### 1. Server Setup (Ubuntu 22.04 LTS)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Reboot
sudo reboot
```

### 2. Deploy Application

```bash
# Clone repository
git clone <repository-url> /opt/getcodegpt
cd /opt/getcodegpt

# Configure environment
cp .env.example .env
nano .env  # Edit with your credentials

# Start services
docker-compose up -d

# Check status
docker-compose ps
docker-compose logs -f bot
```

### 3. Monitoring

```bash
# View logs
docker-compose logs -f

# Check resource usage
docker stats

# Restart services
docker-compose restart bot
```

## Environment Configuration

### Required Variables

```env
TELEGRAM_TOKEN=1234567890:ABCDEF...
GEMINI_API_KEY=AIzaSy...
CRYPTOBOT_API_KEY=12345:AA...
```

### Production Settings

```env
DATABASE_URL=postgresql://user:pass@db:5432/getcodegpt
REDIS_URL=redis://redis:6379
SENTRY_DSN=https://...@sentry.io/...
ENVIRONMENT=production
```

## Database Management

### PostgreSQL Backup

```bash
# Create backup
docker-compose exec db pg_dump -U postgres getcodegpt > backup_$(date +%Y%m%d).sql

# Restore backup
cat backup_20240101.sql | docker-compose exec -T db psql -U postgres getcodegpt
```

### Migration

```bash
# Run migrations
docker-compose exec bot python -c "from models import init_db; init_db()"
```

## Security Best Practices

1. **Firewall Configuration**
```bash
sudo ufw allow 22/tcp  # SSH
sudo ufw allow 80/tcp  # HTTP
sudo ufw allow 443/tcp # HTTPS
sudo ufw enable
```

2. **SSL Certificates** (if using webhooks)
```bash
sudo apt install certbot
sudo certbot certonly --standalone -d yourdomain.com
```

3. **Secrets Management**
- Never commit .env file
- Use strong passwords
- Rotate API keys regularly
- Enable 2FA on all accounts

## Scaling

### Vertical Scaling

Edit `docker-compose.yml`:

```yaml
services:
  bot:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 4G
```

### Horizontal Scaling

Use multiple bot instances with load balancer (advanced).

## Monitoring & Alerts

### Sentry Configuration

1. Create account at sentry.io
2. Create new project
3. Copy DSN to .env
4. Monitor dashboard

### Custom Alerts

Set up Prometheus/Grafana for advanced monitoring.

## Backup Strategy

### Automated Backups

Create cron job:

```bash
# Edit crontab
crontab -e

# Add daily backup at 3 AM
0 3 * * * /opt/getcodegpt/scripts/backup.sh
```

Create `scripts/backup.sh`:

```bash
#!/bin/bash
BACKUP_DIR="/opt/backups/getcodegpt"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup database
docker-compose -f /opt/getcodegpt/docker-compose.yml exec -T db \
  pg_dump -U postgres getcodegpt > $BACKUP_DIR/db_$DATE.sql

# Backup Redis
docker-compose -f /opt/getcodegpt/docker-compose.yml exec -T redis \
  redis-cli SAVE
docker cp getcodegpt_redis:/data/dump.rdb $BACKUP_DIR/redis_$DATE.rdb

# Keep only last 7 days
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.rdb" -mtime +7 -delete
```

Make executable:
```bash
chmod +x scripts/backup.sh
```

## Troubleshooting

### Bot Not Responding

```bash
# Check if running
docker-compose ps

# Check logs
docker-compose logs --tail=100 bot

# Restart
docker-compose restart bot
```

### Database Connection Error

```bash
# Check database
docker-compose exec db psql -U postgres -c "\l"

# Reset database
docker-compose down
docker volume rm getcodegpt_postgres_data
docker-compose up -d
```

### High Memory Usage

```bash
# Check memory
docker stats

# Restart services
docker-compose restart

# Clear Redis cache
docker-compose exec redis redis-cli FLUSHALL
```

## Updating

### Update Application

```bash
cd /opt/getcodegpt
git pull
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

### Update Dependencies

```bash
# Edit requirements.txt
docker-compose build --no-cache bot
docker-compose up -d
```

## Health Checks

Create `health_check.sh`:

```bash
#!/bin/bash

# Check if bot container is running
if ! docker-compose ps | grep -q "bot.*Up"; then
    echo "Bot is down! Restarting..."
    docker-compose restart bot
    # Send alert (implement notification)
fi

# Check database connection
if ! docker-compose exec -T db pg_isready -U postgres; then
    echo "Database is down! Restarting..."
    docker-compose restart db
fi

# Check Redis
if ! docker-compose exec -T redis redis-cli ping | grep -q "PONG"; then
    echo "Redis is down! Restarting..."
    docker-compose restart redis
fi
```

Add to crontab:
```bash
*/5 * * * * /opt/getcodegpt/health_check.sh >> /var/log/getcodegpt_health.log 2>&1
```

## Performance Optimization

1. **Database Indexes**
```sql
CREATE INDEX idx_users_telegram_id ON users(telegram_id);
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_invoice_id ON transactions(invoice_id);
```

2. **Redis Configuration**
```bash
# Edit redis.conf
maxmemory 256mb
maxmemory-policy allkeys-lru
```

3. **PostgreSQL Tuning**
```sql
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
SELECT pg_reload_conf();
```

## Support

For issues:
- Email: jesqweb@gmail.com
- Telegram: @jesqman