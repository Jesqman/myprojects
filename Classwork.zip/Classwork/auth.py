from flask import Blueprint, redirect, url_for, session, request, flash, render_template, current_app
from authlib.integrations.flask_client import OAuth
from flask_login import login_user, logout_user, current_user, login_required
from models import db, User, Invitation, UserSettings
from forms import LoginForm, RegistrationForm, ResetPasswordForm, RequestResetForm
import secrets
from datetime import datetime, timedelta
from urllib.parse import urlparse, urljoin

auth_bp = Blueprint('auth', __name__)

oauth = OAuth()

def init_oauth(app):
    oauth.init_app(app)
    oauth.register(
        name='google',
        client_id=app.config['GOOGLE_CLIENT_ID'],
        client_secret=app.config['GOOGLE_CLIENT_SECRET'],
        server_metadata_url='https://accounts.google.com/.well-known/openid_configuration',
        client_kwargs={
            'scope': 'openid email profile'
        }
    )

def is_safe_url(target):
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    form = LoginForm()
    
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        
        if user and user.check_password(form.password.data):
            if user.is_active:
                login_user(user, remember=form.remember.data)
                user.last_login = datetime.utcnow()
                db.session.commit()
                
                next_page = request.args.get('next')
                if next_page and is_safe_url(next_page):
                    return redirect(next_page)
                
                flash(f'Добро пожаловать, {user.full_name}!', 'success')
                return redirect(url_for('dashboard.index'))
            else:
                flash('Ваш аккаунт деактивирован. Свяжитесь с администратором.', 'error')
        else:
            flash('Неверный email или пароль.', 'error')
    
    return render_template('auth/login.html', form=form)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    form = RegistrationForm()
    
    if form.validate_on_submit():
        # Check if user exists
        if User.query.filter_by(email=form.email.data).first():
            flash('Пользователь с таким email уже существует.', 'error')
            return render_template('auth/register.html', form=form)
        
        # Check for invitation
        invitation = Invitation.query.filter_by(
            email=form.email.data,
            status='pending'
        ).filter(Invitation.expires_at > datetime.utcnow()).first()
        
        if not invitation:
            flash('Для регистрации требуется приглашение.', 'error')
            return render_template('auth/register.html', form=form)
        
        user = User(
            email=form.email.data,
            full_name=form.full_name.data,
            role=invitation.role,
            class_id=invitation.class_id
        )
        user.set_password(form.password.data)
        
        db.session.add(user)
        invitation.status = 'accepted'
        
        # Create user settings
        settings = UserSettings(user=user)
        db.session.add(settings)
        
        db.session.commit()
        
        flash('Регистрация успешна! Теперь вы можете войти.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register.html', form=form)

@auth_bp.route('/login/google')
def google_login():
    if not current_app.config.get('GOOGLE_CLIENT_ID'):
        flash('Google OAuth не настроен. Используйте вход по email.', 'error')
        return redirect(url_for('auth.login'))
    
    redirect_uri = url_for('auth.google_auth', _external=True)
    return oauth.google.authorize_redirect(redirect_uri)

@auth_bp.route('/login/google/callback')
def google_auth():
    try:
        token = oauth.google.authorize_access_token()
        user_info = token.get('userinfo')
        
        if not user_info:
            flash('Ошибка аутентификации. Попробуйте снова.', 'error')
            return redirect(url_for('auth.login'))
        
        user = User.query.filter_by(email=user_info['email']).first()
        
        if not user:
            # Check for pending invitations
            invitation = Invitation.query.filter_by(
                email=user_info['email'],
                status='pending'
            ).filter(Invitation.expires_at > datetime.utcnow()).first()
            
            if invitation:
                user = User(
                    email=user_info['email'],
                    full_name=user_info.get('name', user_info['email']),
                    role=invitation.role,
                    google_id=user_info['sub'],
                    class_id=invitation.class_id,
                    avatar_url=user_info.get('picture')
                )
                db.session.add(user)
                invitation.status = 'accepted'
                
                # Create user settings
                settings = UserSettings(user=user)
                db.session.add(settings)
                
                db.session.commit()
            else:
                flash('Для регистрации требуется приглашение.', 'error')
                return redirect(url_for('auth.login'))
        
        login_user(user, remember=True)
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        flash(f'Добро пожаловать, {user.full_name}!', 'success')
        return redirect(url_for('dashboard.index'))
        
    except Exception as e:
        current_app.logger.error(f'Google OAuth error: {str(e)}')
        flash('Ошибка аутентификации. Попробуйте снова.', 'error')
        return redirect(url_for('auth.login'))

@auth_bp.route('/reset_password', methods=['GET', 'POST'])
def reset_request():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    form = RequestResetForm()
    
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            # Here you would typically send an email with reset token
            token = user.get_reset_token()
            flash('Инструкции по сбросу пароля отправлены на ваш email.', 'info')
            # In production, send email with reset link
            # send_reset_email(user, token)
        else:
            flash('Если email существует, инструкции будут отправлены.', 'info')
        
        return redirect(url_for('auth.login'))
    
    return render_template('auth/reset_request.html', form=form)

@auth_bp.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_token(token):
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    user = User.verify_reset_token(token)
    if not user:
        flash('Неверный или просроченный токен.', 'error')
        return redirect(url_for('auth.reset_request'))
    
    form = ResetPasswordForm()
    
    if form.validate_on_submit():
        user.set_password(form.password.data)
        db.session.commit()
        flash('Ваш пароль был обновлен!', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/reset_token.html', form=form)

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы успешно вышли из системы.', 'info')
    return redirect(url_for('auth.login'))