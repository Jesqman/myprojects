from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import db, Collection, Payment, User
from forms import CollectionForm, PaymentForm
from datetime import datetime
from werkzeug.utils import secure_filename

finance_bp = Blueprint('finance', __name__)

@finance_bp.route('/')
@login_required
def index():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('dashboard.index'))
    
    user_class = current_user.class_rel
    collections = Collection.query.filter_by(class_id=user_class.id).all() if user_class else []
    
    return render_template('finance/index.html', collections=collections)

@finance_bp.route('/collections')
@login_required
def collections():
    user_class = current_user.class_rel
    
    if current_user.role in ['teacher', 'starosta', 'admin']:
        collections = Collection.query.filter_by(class_id=user_class.id).all() if user_class else []
    else:
        # Students can only see active collections
        collections = Collection.query.filter_by(class_id=user_class.id)\
            .filter(Collection.end_date >= datetime.now().date()).all() if user_class else []
    
    return render_template('finance/collections.html', collections=collections)

@finance_bp.route('/collection/<int:collection_id>')
@login_required
def collection_detail(collection_id):
    collection = Collection.query.get_or_404(collection_id)
    
    # Check if user has access to this collection
    if collection.class_id != current_user.class_rel.id and not current_user.is_admin():
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('finance.collections'))
    
    payments = Payment.query.filter_by(collection_id=collection_id).all()
    
    # Calculate progress
    progress_percentage = (collection.current_amount / collection.target_amount * 100) if collection.target_amount > 0 else 0
    days_left = (collection.end_date - datetime.now().date()).days
    
    return render_template('finance/collection_detail.html', 
                         collection=collection, 
                         payments=payments,
                         progress_percentage=round(progress_percentage, 1),
                         days_left=days_left)

@finance_bp.route('/collection/add', methods=['GET', 'POST'])
@login_required
def add_collection():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('finance.index'))
    
    form = CollectionForm()
    
    if form.validate_on_submit():
        collection = Collection(
            name=form.name.data,
            description=form.description.data,
            target_amount=form.target_amount.data,
            start_date=form.start_date.data,
            end_date=form.end_date.data,
            class_id=current_user.class_rel.id,
            created_by=current_user.id
        )
        
        if form.collection_logo.data:
            filename = secure_filename(form.collection_logo.data.filename)
            filepath = f'static/uploads/collection_logos/{filename}'
            form.collection_logo.data.save(filepath)
            collection.collection_logo = f'/{filepath}'
        
        db.session.add(collection)
        db.session.commit()
        flash('Сбор успешно создан!', 'success')
        return redirect(url_for('finance.collections'))
    
    return render_template('finance/collection_form.html', form=form, action='add')

@finance_bp.route('/collection/<int:collection_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_collection(collection_id):
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('finance.index'))
    
    collection = Collection.query.get_or_404(collection_id)
    
    # Check if collection belongs to user's class
    if collection.class_id != current_user.class_rel.id:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('finance.collections'))
    
    form = CollectionForm()
    
    if form.validate_on_submit():
        collection.name = form.name.data
        collection.description = form.description.data
        collection.target_amount = form.target_amount.data
        collection.start_date = form.start_date.data
        collection.end_date = form.end_date.data
        
        if form.collection_logo.data:
            filename = secure_filename(form.collection_logo.data.filename)
            filepath = f'static/uploads/collection_logos/{filename}'
            form.collection_logo.data.save(filepath)
            collection.collection_logo = f'/{filepath}'
        
        db.session.commit()
        flash('Сбор успешно обновлен!', 'success')
        return redirect(url_for('finance.collection_detail', collection_id=collection.id))
    
    elif request.method == 'GET':
        form.name.data = collection.name
        form.description.data = collection.description
        form.target_amount.data = collection.target_amount
        form.start_date.data = collection.start_date
        form.end_date.data = collection.end_date
    
    return render_template('finance/collection_form.html', form=form, action='edit', collection=collection)

@finance_bp.route('/payment/add', methods=['GET', 'POST'])
@login_required
def add_payment():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('finance.index'))
    
    form = PaymentForm()
    
    # Populate student and collection choices
    user_class = current_user.class_rel
    form.student_id.choices = [(s.id, s.full_name) for s in user_class.users if s.role == 'student']
    form.collection_id.choices = [(c.id, c.name) for c in user_class.collections]
    
    if form.validate_on_submit():
        payment = Payment(
            student_id=form.student_id.data,
            collection_id=form.collection_id.data,
            amount=form.amount.data,
            status=form.status.data,
            notes=form.notes.data,
            payment_date=datetime.utcnow()
        )
        
        db.session.add(payment)
        
        # Update collection current amount
        if form.status.data == 'paid':
            collection = Collection.query.get(form.collection_id.data)
            collection.current_amount += form.amount.data
        
        db.session.commit()
        flash('Платеж успешно добавлен!', 'success')
        return redirect(url_for('finance.collections'))
    
    return render_template('finance/payment_form.html', form=form)

@finance_bp.route('/api/collections/stats')
@login_required
def collections_stats():
    user_class = current_user.class_rel
    if not user_class:
        return jsonify({'error': 'No class found'}), 404
    
    collections = Collection.query.filter_by(class_id=user_class.id).all()
    
    stats = {
        'total_collections': len(collections),
        'active_collections': len([c for c in collections if c.end_date >= datetime.now().date()]),
        'total_target': sum(c.target_amount for c in collections),
        'total_collected': sum(c.current_amount for c in collections),
        'completion_rate': 0
    }
    
    if stats['total_target'] > 0:
        stats['completion_rate'] = round((stats['total_collected'] / stats['total_target']) * 100, 1)
    
    return jsonify(stats)