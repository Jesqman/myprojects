from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from models import db, User, Class, Lesson, Attendance, Collection, Invitation
from forms import AdminUserForm, AdminClassForm
from datetime import datetime

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash('Доступ запрещен. Требуются права администратора.', 'error')
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/')
@login_required
@admin_required
def index():
    stats = {
        'total_users': User.query.count(),
        'total_classes': Class.query.count(),
        'total_lessons': Lesson.query.count(),
        'active_collections': Collection.query.filter(Collection.end_date >= datetime.now().date()).count(),
        'pending_invitations': Invitation.query.filter_by(status='pending').count()
    }
    
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    recent_classes = Class.query.order_by(Class.created_date.desc()).limit(5).all()
    
    return render_template('admin/index.html',
                         stats=stats,
                         recent_users=recent_users,
                         recent_classes=recent_classes)

@admin_bp.route('/users')
@login_required
@admin_required
def users():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    search = request.args.get('search', '')
    role_filter = request.args.get('role', '')
    
    query = User.query
    
    if search:
        query = query.filter(
            (User.full_name.ilike(f'%{search}%')) | 
            (User.email.ilike(f'%{search}%'))
        )
    
    if role_filter:
        query = query.filter(User.role == role_filter)
    
    users_pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('admin/users.html',
                         users=users_pagination.items,
                         pagination=users_pagination,
                         search=search,
                         role_filter=role_filter)

@admin_bp.route('/user/<int:user_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def user_detail(user_id):
    user = User.query.get_or_404(user_id)
    form = AdminUserForm()
    
    if form.validate_on_submit():
        user.role = form.role.data
        user.is_active = form.is_active.data
        
        if form.class_id.data:
            user.class_id = form.class_id.data
        else:
            user.class_id = None
        
        db.session.commit()
        flash('Данные пользователя успешно обновлены!', 'success')
        return redirect(url_for('admin.user_detail', user_id=user.id))
    
    elif request.method == 'GET':
        form.role.data = user.role
        form.is_active.data = user.is_active
        form.class_id.data = user.class_id
    
    # Get user statistics
    user_stats = {}
    if user.role == 'student':
        user_stats['attendance_count'] = Attendance.query.filter_by(student_id=user.id).count()
        user_stats['present_count'] = Attendance.query.filter_by(student_id=user.id, status='present').count()
        user_stats['payments_count'] = len(user.payments)
    
    return render_template('admin/user_detail.html',
                         user=user,
                         form=form,
                         user_stats=user_stats)

@admin_bp.route('/user/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    
    # Prevent self-deletion
    if user.id == current_user.id:
        flash('Вы не можете удалить свой собственный аккаунт!', 'error')
        return redirect(url_for('admin.user_detail', user_id=user_id))
    
    # Check if user is the only teacher in their class
    if user.role == 'teacher' and user.class_rel:
        other_teachers = User.query.filter_by(
            class_id=user.class_rel.id, 
            role='teacher'
        ).filter(User.id != user.id).count()
        
        if other_teachers == 0:
            flash('Нельзя удалить единственного учителя в классе!', 'error')
            return redirect(url_for('admin.user_detail', user_id=user_id))
    
    db.session.delete(user)
    db.session.commit()
    flash(f'Пользователь {user.full_name} успешно удален!', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/classes')
@login_required
@admin_required
def classes():
    classes_list = Class.query.all()
    return render_template('admin/classes.html', classes=classes_list)

@admin_bp.route('/class/<int:class_id>')
@login_required
@admin_required
def class_detail(class_id):
    class_obj = Class.query.get_or_404(class_id)
    students = User.query.filter_by(class_id=class_id, role='student').all()
    teachers = User.query.filter_by(class_id=class_id, role='teacher').all()
    starostas = User.query.filter_by(class_id=class_id, role='starosta').all()
    
    return render_template('admin/class_detail.html',
                         class_obj=class_obj,
                         students=students,
                         teachers=teachers,
                         starostas=starostas)

@admin_bp.route('/analytics')
@login_required
@admin_required
def analytics():
    # User growth over time
    users_by_date = db.session.query(
        db.func.date(User.created_at).label('date'),
        db.func.count(User.id).label('count')
    ).group_by(db.func.date(User.created_at)).all()
    
    # Users by role
    users_by_role = db.session.query(
        User.role,
        db.func.count(User.id).label('count')
    ).group_by(User.role).all()
    
    # Classes statistics
    classes_stats = {
        'total': Class.query.count(),
        'with_teachers': Class.query.filter(Class.teacher_id.isnot(None)).count(),
        'with_students': db.session.query(Class).join(User).filter(User.role == 'student').distinct().count()
    }
    
    return render_template('admin/analytics.html',
                         users_by_date=users_by_date,
                         users_by_role=users_by_role,
                         classes_stats=classes_stats)

@admin_bp.route('/api/user_stats')
@login_required
@admin_required
def user_stats():
    """API endpoint for user statistics"""
    total_users = User.query.count()
    users_by_role = {
        role: User.query.filter_by(role=role).count()
        for role in ['admin', 'teacher', 'student', 'starosta']
    }
    
    return jsonify({
        'total_users': total_users,
        'users_by_role': users_by_role,
        'active_users': User.query.filter_by(is_active=True).count()
    })

@admin_bp.route('/invitations')
@login_required
@admin_required
def invitations():
    pending_invitations = Invitation.query.filter_by(status='pending').all()
    return render_template('admin/invitations.html', invitations=pending_invitations)

@admin_bp.route('/invitation/<int:invitation_id>/resend', methods=['POST'])
@login_required
@admin_required
def resend_invitation(invitation_id):
    invitation = Invitation.query.get_or_404(invitation_id)
    
    # In production, you would send an actual email here
    flash(f'Приглашение для {invitation.email} отправлено повторно!', 'success')
    return redirect(url_for('admin.invitations'))

@admin_bp.route('/invitation/<int:invitation_id>/cancel', methods=['POST'])
@login_required
@admin_required
def cancel_invitation(invitation_id):
    invitation = Invitation.query.get_or_404(invitation_id)
    invitation.status = 'expired'
    db.session.commit()
    
    flash(f'Приглашение для {invitation.email} отменено!', 'success')
    return redirect(url_for('admin.invitations'))