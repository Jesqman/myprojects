from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
import bcrypt
import jwt
from flask import current_app

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.Enum('admin', 'teacher', 'student', 'starosta'), nullable=False, default='student')
    avatar_url = db.Column(db.String(500), default='/static/images/default-avatar.png')
    google_id = db.Column(db.String(100), unique=True)
    password_hash = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    email_verified = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Settings
    notifications_enabled = db.Column(db.Boolean, default=True)
    language = db.Column(db.String(10), default='ru')
    theme = db.Column(db.String(20), default='light')
    
    # Relationships
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'))
    class_rel = db.relationship('Class', back_populates='users')
    attendance_records = db.relationship('Attendance', back_populates='student')
    payments = db.relationship('Payment', back_populates='student')
    created_collections = db.relationship('Collection', back_populates='created_by_user')
    settings = db.relationship('UserSettings', back_populates='user', uselist=False)

    def set_password(self, password):
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))

    def is_admin(self):
        return self.role == 'admin'

    def get_reset_token(self, expires_sec=1800):
        payload = {
            'user_id': self.id,
            'exp': datetime.utcnow() + timedelta(seconds=expires_sec)
        }
        return jwt.encode(payload, current_app.config['SECRET_KEY'], algorithm='HS256')

    @staticmethod
    def verify_reset_token(token):
        try:
            payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            user_id = payload['user_id']
        except:
            return None
        return User.query.get(user_id)

class Class(db.Model):
    __tablename__ = 'classes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    class_logo = db.Column(db.String(500), default='/static/images/default-class-logo.png')
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    modified_date = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    users = db.relationship('User', back_populates='class_rel')
    teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    teacher = db.relationship('User', foreign_keys=[teacher_id])
    lessons = db.relationship('Lesson', back_populates='class_rel')
    collections = db.relationship('Collection', back_populates='class_rel')

class Lesson(db.Model):
    __tablename__ = 'lessons'
    
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'))
    class_rel = db.relationship('Class', back_populates='lessons')
    attendance_records = db.relationship('Attendance', back_populates='lesson')

class Attendance(db.Model):
    __tablename__ = 'attendance'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    status = db.Column(db.Enum('present', 'absent', 'late', 'dismissed_early'), nullable=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    student = db.relationship('User', back_populates='attendance_records')
    lesson_id = db.Column(db.Integer, db.ForeignKey('lessons.id'))
    lesson = db.relationship('Lesson', back_populates='attendance_records')

class Collection(db.Model):
    __tablename__ = 'collections'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    target_amount = db.Column(db.Float, nullable=False)
    current_amount = db.Column(db.Float, default=0.0)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    collection_logo = db.Column(db.String(500), default='/static/images/default-collection-logo.png')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'))
    class_rel = db.relationship('Class', back_populates='collections')
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_by_user = db.relationship('User', back_populates='created_collections')
    payments = db.relationship('Payment', back_populates='collection')

class Payment(db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    amount = db.Column(db.Float, nullable=False)
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.Enum('paid', 'unpaid', 'partial'), default='unpaid')
    notes = db.Column(db.Text)
    
    # Relationships
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    student = db.relationship('User', back_populates='payments')
    collection_id = db.Column(db.Integer, db.ForeignKey('collections.id'))
    collection = db.relationship('Collection', back_populates='payments')

class Invitation(db.Model):
    __tablename__ = 'invitations'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), nullable=False)
    token = db.Column(db.String(200), nullable=False, unique=True)
    role = db.Column(db.Enum('teacher', 'student', 'starosta'), nullable=False)
    status = db.Column(db.Enum('pending', 'accepted', 'expired'), default='pending')
    expires_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'))

class UserSettings(db.Model):
    __tablename__ = 'user_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Notification settings
    email_notifications = db.Column(db.Boolean, default=True)
    lesson_reminders = db.Column(db.Boolean, default=True)
    payment_reminders = db.Column(db.Boolean, default=True)
    attendance_alerts = db.Column(db.Boolean, default=True)
    
    # Display settings
    items_per_page = db.Column(db.Integer, default=20)
    compact_view = db.Column(db.Boolean, default=False)
    
    user = db.relationship('User', back_populates='settings')

class SystemSettings(db.Model):
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.String(255))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)