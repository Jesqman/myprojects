from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify, current_app
from flask_login import login_required, current_user
from models import db, User, UserSettings, SystemSettings
from forms import SettingsForm, UserSettingsForm, ChangePasswordForm
import os
from datetime import datetime

settings_bp = Blueprint('settings', __name__, url_prefix='/settings')

@settings_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    form = SettingsForm()
    
    if form.validate_on_submit():
        current_user.full_name = form.full_name.data
        current_user.email = form.email.data
        current_user.language = form.language.data
        current_user.theme = form.theme.data
        current_user.notifications_enabled = form.notifications_enabled.data
        
        db.session.commit()
        flash('Настройки профиля успешно обновлены!', 'success')
        return redirect(url_for('settings.profile'))
    
    elif request.method == 'GET':
        form.full_name.data = current_user.full_name
        form.email.data = current_user.email
        form.language.data = current_user.language
        form.theme.data = current_user.theme
        form.notifications_enabled.data = current_user.notifications_enabled
    
    return render_template('settings/profile.html', form=form)

@settings_bp.route('/preferences', methods=['GET', 'POST'])
@login_required
def preferences():
    form = UserSettingsForm()
    
    # Ensure user has settings
    if not current_user.settings:
        settings = UserSettings(user=current_user)
        db.session.add(settings)
        db.session.commit()
        current_user.settings = settings
    
    if form.validate_on_submit():
        current_user.settings.email_notifications = form.email_notifications.data
        current_user.settings.lesson_reminders = form.lesson_reminders.data
        current_user.settings.payment_reminders = form.payment_reminders.data
        current_user.settings.attendance_alerts = form.attendance_alerts.data
        current_user.settings.items_per_page = form.items_per_page.data
        current_user.settings.compact_view = form.compact_view.data
        
        db.session.commit()
        flash('Настройки предпочтений успешно обновлены!', 'success')
        return redirect(url_for('settings.preferences'))
    
    elif request.method == 'GET':
        form.email_notifications.data = current_user.settings.email_notifications
        form.lesson_reminders.data = current_user.settings.lesson_reminders
        form.payment_reminders.data = current_user.settings.payment_reminders
        form.attendance_alerts.data = current_user.settings.attendance_alerts
        form.items_per_page.data = current_user.settings.items_per_page
        form.compact_view.data = current_user.settings.compact_view
    
    return render_template('settings/preferences.html', form=form)

@settings_bp.route('/security', methods=['GET', 'POST'])
@login_required
def security():
    form = ChangePasswordForm()
    
    if form.validate_on_submit():
        if not current_user.check_password(form.current_password.data):
            flash('Текущий пароль неверен.', 'error')
            return render_template('settings/security.html', form=form)
        
        current_user.set_password(form.new_password.data)
        db.session.commit()
        flash('Пароль успешно изменен!', 'success')
        return redirect(url_for('settings.security'))
    
    return render_template('settings/security.html', form=form)

@settings_bp.route('/system', methods=['GET', 'POST'])
@login_required
def system_settings():
    if not current_user.is_admin():
        flash('Доступ запрещен. Требуются права администратора.', 'error')
        return redirect(url_for('dashboard.index'))
    
    if request.method == 'POST':
        for key in request.form:
            if key.startswith('setting_'):
                setting_key = key.replace('setting_', '')
                setting = SystemSettings.query.filter_by(key=setting_key).first()
                if setting:
                    setting.value = request.form[key]
                    setting.updated_at = datetime.utcnow()
        
        db.session.commit()
        flash('Системные настройки успешно обновлены!', 'success')
        return redirect(url_for('settings.system_settings'))
    
    # Get or create default system settings
    settings = SystemSettings.query.all()
    if not settings:
        # Create default settings
        default_settings = [
            ('site_name', 'Classwork', 'Название сайта'),
            ('site_description', 'Educational Management Platform', 'Описание сайта'),
            ('default_language', 'ru', 'Язык по умолчанию'),
            ('items_per_page', '20', 'Элементов на странице по умолчанию'),
            ('allow_registration', 'true', 'Разрешить регистрацию'),
            ('require_invitation', 'true', 'Требовать приглашение для регистрации'),
            ('google_oauth_enabled', 'false', 'Включить Google OAuth'),
            ('file_upload_max_size', '16', 'Максимальный размер файла (MB)'),
            ('session_timeout', '60', 'Таймаут сессии (минуты)'),
            ('backup_enabled', 'false', 'Включить автоматическое резервное копирование'),
            ('backup_interval', '24', 'Интервал резервного копирования (часы)'),
            ('email_notifications', 'true', 'Включить email уведомления'),
            ('smtp_server', '', 'SMTP сервер'),
            ('smtp_port', '587', 'SMTP порт'),
            ('smtp_username', '', 'SMTP пользователь'),
            ('smtp_password', '', 'SMTP пароль'),
        ]
        
        for key, value, description in default_settings:
            setting = SystemSettings(key=key, value=value, description=description)
            db.session.add(setting)
        
        db.session.commit()
        settings = SystemSettings.query.all()
    
    return render_template('settings/system.html', settings=settings)

@settings_bp.route('/api/update_theme', methods=['POST'])
@login_required
def update_theme():
    data = request.get_json()
    theme = data.get('theme', 'light')
    
    if theme not in ['light', 'dark']:
        return jsonify({'error': 'Invalid theme'}), 400
    
    current_user.theme = theme
    db.session.commit()
    
    return jsonify({'message': 'Theme updated successfully', 'theme': theme})

@settings_bp.route('/api/update_language', methods=['POST'])
@login_required
def update_language():
    data = request.get_json()
    language = data.get('language', 'ru')
    
    if language not in ['ru', 'en']:
        return jsonify({'error': 'Invalid language'}), 400
    
    current_user.language = language
    db.session.commit()
    
    return jsonify({'message': 'Language updated successfully', 'language': language})

@settings_bp.route('/backup', methods=['POST'])
@login_required
def create_backup():
    if not current_user.is_admin():
        return jsonify({'error': 'Доступ запрещен'}), 403
    
    try:
        # Simple backup implementation - in production you'd use proper backup tools
        backup_dir = 'backups'
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = f'{backup_dir}/backup_{timestamp}.sql'
        
        # This is a simplified backup - in production use proper database backup tools
        with open(backup_file, 'w') as f:
            f.write(f"# Classwork Backup - {timestamp}\n")
            f.write(f"# Generated automatically by the system\n")
        
        flash(f'Резервная копия создана: backup_{timestamp}.sql', 'success')
        return jsonify({'message': 'Backup created successfully', 'file': f'backup_{timestamp}.sql'})
    
    except Exception as e:
        current_app.logger.error(f'Backup error: {str(e)}')
        return jsonify({'error': 'Failed to create backup'}), 500

@settings_bp.route('/logs')
@login_required
def view_logs():
    if not current_user.is_admin():
        flash('Доступ запрещен. Требуются права администратора.', 'error')
        return redirect(url_for('dashboard.index'))
    
    log_file = 'classwork.log'
    logs = []
    
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r', encoding='utf-8') as f:
                # Read last 100 lines
                lines = f.readlines()[-100:]
                logs = [line.strip() for line in lines if line.strip()]
        except Exception as e:
            logs = [f'Error reading log file: {str(e)}']
    
    return render_template('settings/logs.html', logs=logs)

@settings_bp.route('/api/system_info')
@login_required
def system_info():
    if not current_user.is_admin():
        return jsonify({'error': 'Доступ запрещен'}), 403
    
    import platform
    import psutil
    import sqlite3
    
    try:
        # System information
        system_info = {
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'flask_version': current_app.config.get('VERSION', '1.0.0'),
            'database_url': current_app.config['SQLALCHEMY_DATABASE_URI'],
            'debug_mode': current_app.config['DEBUG']
        }
        
        # Memory usage
        memory = psutil.virtual_memory()
        system_info['memory_usage'] = {
            'total': round(memory.total / (1024 ** 3), 2),
            'used': round(memory.used / (1024 ** 3), 2),
            'percent': memory.percent
        }
        
        # Disk usage
        disk = psutil.disk_usage('/')
        system_info['disk_usage'] = {
            'total': round(disk.total / (1024 ** 3), 2),
            'used': round(disk.used / (1024 ** 3), 2),
            'percent': disk.percent
        }
        
        # Database statistics
        from models import User, Class, Lesson, Attendance, Collection
        system_info['database_stats'] = {
            'users': User.query.count(),
            'classes': Class.query.count(),
            'lessons': Lesson.query.count(),
            'attendance_records': Attendance.query.count(),
            'collections': Collection.query.count()
        }
        
        return jsonify(system_info)
    
    except Exception as e:
        current_app.logger.error(f'System info error: {str(e)}')
        return jsonify({'error': 'Failed to get system information'}), 500

@settings_bp.route('/api/health')
def health_check():
    """Health check endpoint for monitoring"""
    try:
        # Basic health checks
        db_ok = False
        try:
            db.session.execute('SELECT 1')
            db_ok = True
        except:
            pass
        
        status = 'healthy' if db_ok else 'unhealthy'
        
        return jsonify({
            'status': status,
            'timestamp': datetime.utcnow().isoformat(),
            'database': 'ok' if db_ok else 'error',
            'version': '1.0.0'
        })
    
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500