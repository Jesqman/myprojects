from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import db, Class, User, Lesson, Attendance, Collection, Invitation
from forms import ClassForm, InvitationForm
import secrets
from datetime import datetime, timedelta
from werkzeug.utils import secure_filename

classes_bp = Blueprint('classes', __name__)

@classes_bp.route('/')
@login_required
def manage():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('dashboard.index'))
    
    user_class = current_user.class_rel
    students = User.query.filter_by(class_id=user_class.id, role='student').all() if user_class else []
    return render_template('classes/manage.html', class_obj=user_class, students=students)

@classes_bp.route('/edit', methods=['GET', 'POST'])
@login_required
def edit():
    if current_user.role not in ['teacher', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('classes.manage'))
    
    user_class = current_user.class_rel
    form = ClassForm()
    
    if form.validate_on_submit():
        user_class.name = form.name.data
        user_class.description = form.description.data
        
        if form.class_logo.data:
            filename = secure_filename(form.class_logo.data.filename)
            filepath = f'static/uploads/class_logos/{filename}'
            form.class_logo.data.save(filepath)
            user_class.class_logo = f'/{filepath}'
        
        user_class.modified_date = datetime.utcnow()
        db.session.commit()
        flash('Информация о классе обновлена!', 'success')
        return redirect(url_for('classes.manage'))
    
    elif request.method == 'GET':
        form.name.data = user_class.name
        form.description.data = user_class.description
    
    return render_template('classes/form.html', form=form, action='edit')

@classes_bp.route('/invite', methods=['GET', 'POST'])
@login_required
def invite():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('dashboard.index'))
    
    form = InvitationForm()
    
    if form.validate_on_submit():
        # Check if user already exists
        existing_user = User.query.filter_by(email=form.email.data).first()
        if existing_user:
            flash('Пользователь с таким email уже существует.', 'error')
            return render_template('classes/invite.html', form=form)
        
        # Check for existing invitation
        existing_invitation = Invitation.query.filter_by(
            email=form.email.data,
            status='pending'
        ).first()
        
        if existing_invitation:
            flash('Приглашение для этого email уже отправлено.', 'error')
            return render_template('classes/invite.html', form=form)
        
        # Create invitation
        token = secrets.token_urlsafe(32)
        invitation = Invitation(
            email=form.email.data,
            token=token,
            role=form.role.data,
            class_id=current_user.class_rel.id,
            expires_at=datetime.utcnow() + timedelta(days=7)
        )
        
        db.session.add(invitation)
        db.session.commit()
        
        # In production, send email with invitation link
        flash(f'Приглашение отправлено на {form.email.data}!', 'success')
        return redirect(url_for('classes.manage'))
    
    return render_template('classes/invite.html', form=form)

@classes_bp.route('/students')
@login_required
def students():
    user_class = current_user.class_rel
    if not user_class:
        return jsonify({'error': 'No class found'}), 404
    
    students = User.query.filter_by(class_id=user_class.id, role='student').all()
    student_data = []
    
    for student in students:
        # Calculate attendance stats
        total_lessons = Lesson.query.filter_by(class_id=user_class.id).count()
        present_count = Attendance.query.filter_by(student_id=student.id, status='present').count()
        attendance_percentage = (present_count / total_lessons * 100) if total_lessons > 0 else 0
        
        student_data.append({
            'id': student.id,
            'name': student.full_name,
            'email': student.email,
            'attendance_percentage': round(attendance_percentage, 1),
            'last_login': student.last_login.isoformat() if student.last_login else None
        })
    
    return jsonify(student_data)