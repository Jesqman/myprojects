from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, current_user, login_required
from flask_migrate import Migrate
from models import db, User, Class, Lesson, Attendance, Collection, Payment, Invitation, UserSettings, SystemSettings
from auth import auth_bp, init_oauth
from forms import LoginForm, RegistrationForm
from datetime import datetime
import os
from werkzeug.utils import secure_filename

# Blueprints
from dashboard import dashboard_bp
from classes import classes_bp
from schedule import schedule_bp
from attendance import attendance_bp
from finance import finance_bp
from admin import admin_bp
from settings import settings_bp

def create_app():
    app = Flask(__name__)
    
    # Load configuration
    if os.path.exists('.env'):
        from dotenv import load_dotenv
        load_dotenv()
    
    app.config.from_object('config.Config')
    
    # Initialize extensions
    db.init_app(app)
    
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Пожалуйста, войдите для доступа к этой странице.'
    
    migrate = Migrate(app, db)
    
    # Initialize OAuth
    init_oauth(app)
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/dashboard')
    app.register_blueprint(classes_bp, url_prefix='/classes')
    app.register_blueprint(schedule_bp, url_prefix='/schedule')
    app.register_blueprint(attendance_bp, url_prefix='/attendance')
    app.register_blueprint(finance_bp, url_prefix='/finance')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(settings_bp, url_prefix='/settings')
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Create admin user and default settings on first run
    @app.before_first_request
    def create_default_data():
        # Create admin user
        admin_email = 'admin@support.com'
        admin_user = User.query.filter_by(email=admin_email).first()
        
        if not admin_user:
            admin_user = User(
                email=admin_email,
                full_name='System Administrator',
                role='admin'
            )
            admin_user.set_password('AADDMM1337')
            db.session.add(admin_user)
            
            # Create default system settings
            default_settings = [
                ('site_name', 'Classwork', 'Название сайта'),
                ('site_description', 'Educational Management Platform', 'Описание сайта'),
                ('default_language', 'ru', 'Язык по умолчанию'),
                ('items_per_page', '20', 'Элементов на странице по умолчанию'),
                ('allow_registration', 'true', 'Разрешить регистрацию'),
                ('require_invitation', 'true', 'Требовать приглашение для регистрации'),
            ]
            
            for key, value, description in default_settings:
                setting = SystemSettings(key=key, value=value, description=description)
                db.session.add(setting)
            
            db.session.commit()
            print("Default admin user created: admin@support.com / AADDMM1337")
    
    # Context processors
    @app.context_processor
    def inject_user():
        return dict(current_user=current_user)
    
    @app.context_processor
    def inject_settings():
        settings = {}
        if current_user.is_authenticated:
            settings['theme'] = current_user.theme
            settings['language'] = current_user.language
        return dict(settings=settings)
    
    # Main route
    @app.route('/')
    def index():
        if current_user.is_authenticated:
            return redirect(url_for('dashboard.index'))
        return render_template('index.html')
    
    # Health check
    @app.route('/health')
    def health():
        return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})
    
    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('errors/500.html'), 500
    
    @app.errorhandler(403)
    def forbidden_error(error):
        return render_template('errors/403.html'), 403
    
    return app

if __name__ == '__main__':
    app = create_app()
    
    with app.app_context():
        db.create_all()
    
    app.run(debug=app.config.get('DEBUG', False), host='0.0.0.0', port=5000)